import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Platform, StyleSheet, Vibration, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import Ionicons from '@expo/vector-icons/Ionicons';
import {
  SafeAreaProvider,
  SafeAreaView,
} from 'react-native-safe-area-context';
import { shelfRepository } from './src/data/appStorage';
import {
  createDefaultStats,
  DEFAULT_SETTINGS,
} from './src/data/ShelfDatabaseRepository';
import { GameEngine } from './src/domain/GameEngine';
import type {
  Difficulty,
  GameSettings,
  GameState,
  PlayerStats,
} from './src/domain/models';
import type { LevelCompletionSummary } from './src/domain/ScoreManager';
import { DifficultyScreen } from './src/screens/DifficultyScreen';
import { GameScreen } from './src/screens/GameScreen';
import { MainMenuScreen } from './src/screens/MainMenuScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { SplashScreen } from './src/screens/SplashScreen';
import { StatsScreen } from './src/screens/StatsScreen';
import { ShelfColors } from './src/theme/colors';

type ActiveRoute =
  | 'SPLASH'
  | 'MAIN_MENU'
  | 'DIFFICULTY'
  | 'GAME'
  | 'STATS'
  | 'SETTINGS';

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
  });

  const gameEngine = useMemo(() => new GameEngine(), []);

  const [route, setRoute] = useState<ActiveRoute>('SPLASH');
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);
  const [playerStats, setPlayerStats] = useState<PlayerStats>(
    createDefaultStats()
  );
  const [savedSession, setSavedSession] = useState<GameState | null>(null);
  const [activeGame, setActiveGame] = useState<GameState | null>(null);
  const [winSummary, setWinSummary] =
    useState<LevelCompletionSummary | null>(null);

  // Load persisted offline Room/AsyncStorage data on startup
  useEffect(() => {
    let mounted = true;
    (async () => {
      const [loadedSettings, loadedStats, loadedSession] = await Promise.all([
        shelfRepository.loadSettings(),
        shelfRepository.loadPlayerStats(),
        shelfRepository.loadActiveSession(),
      ]);
      if (!mounted) return;
      setSettings(loadedSettings);
      setPlayerStats(loadedStats);
      setSavedSession(loadedSession);
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const triggerTactileFeedback = useCallback(
    (durationMs: number = 15) => {
      if (settings.vibrationEnabled && Platform.OS !== 'web') {
        try {
          Vibration.vibrate(durationMs);
        } catch {
          // Ignore on unsupported devices
        }
      }
    },
    [settings.vibrationEnabled]
  );

  const handleStartLevel = useCallback(
    async (difficulty: Difficulty, levelNumber: number) => {
      const freshState = gameEngine.createNewGame(difficulty, levelNumber);
      setWinSummary(null);
      setActiveGame(freshState);
      setSavedSession(freshState);
      setRoute('GAME');
      await shelfRepository.saveActiveSession(freshState);
    },
    [gameEngine]
  );

  const handleResumeSavedGame = useCallback(() => {
    if (!savedSession) return;
    setWinSummary(null);
    setActiveGame({
      ...savedSession,
      status: 'PLAYING',
    });
    setRoute('GAME');
  }, [savedSession]);

  const handleSelectShelfSlot = useCallback(
    async (compartmentId: string, columnIndex: number) => {
      if (!activeGame) return;

      const outcome = gameEngine.selectShelfItem(
        activeGame,
        compartmentId,
        columnIndex,
        settings
      );

      setActiveGame(outcome.state);

      if (outcome.didMatchTriplet) {
        triggerTactileFeedback(35);
      } else {
        triggerTactileFeedback(12);
      }

      if (outcome.state.status === 'WON' && outcome.completionSummary) {
        setWinSummary(outcome.completionSummary);
        setSavedSession(null);
        const updatedStats = await shelfRepository.recordGameWin(
          outcome.state,
          outcome.completionSummary
        );
        setPlayerStats(updatedStats);
      } else if (outcome.state.status === 'LOST') {
        setSavedSession(null);
        const updatedStats = await shelfRepository.recordGameLoss(
          outcome.state
        );
        setPlayerStats(updatedStats);
      } else {
        setSavedSession(outcome.state);
        await shelfRepository.saveActiveSession(outcome.state);
      }
    },
    [activeGame, gameEngine, settings, triggerTactileFeedback]
  );

  const handleUndo = useCallback(
    async (emergencyRevive: boolean = false) => {
      if (!activeGame) return;
      const revertedState = gameEngine.undoLastMove(
        activeGame,
        emergencyRevive
      );
      setActiveGame(revertedState);
      setSavedSession(revertedState);
      triggerTactileFeedback(18);
      await shelfRepository.saveActiveSession(revertedState);
    },
    [activeGame, gameEngine, triggerTactileFeedback]
  );

  const handleHint = useCallback(async () => {
    if (!activeGame) return;
    const hintedState = gameEngine.requestHint(activeGame);
    setActiveGame(hintedState);
    setSavedSession(hintedState);
    triggerTactileFeedback(20);
    await shelfRepository.saveActiveSession(hintedState);
  }, [activeGame, gameEngine, triggerTactileFeedback]);

  const handleTogglePause = useCallback(
    async (paused: boolean) => {
      if (!activeGame) return;
      const nextState = gameEngine.setPaused(activeGame, paused);
      setActiveGame(nextState);
      setSavedSession(nextState);
      await shelfRepository.saveActiveSession(nextState);
    },
    [activeGame, gameEngine]
  );

  const handleRestartLevel = useCallback(async () => {
    if (!activeGame) return;
    const freshState = gameEngine.createNewGame(
      activeGame.difficulty,
      activeGame.levelNumber
    );
    setWinSummary(null);
    setActiveGame(freshState);
    setSavedSession(freshState);
    await shelfRepository.saveActiveSession(freshState);
  }, [activeGame, gameEngine]);

  const handleNextLevel = useCallback(async () => {
    if (!activeGame) return;
    const nextLevelNumber = activeGame.levelNumber + 1;
    const nextState = gameEngine.createNewGame(
      activeGame.difficulty,
      nextLevelNumber
    );
    setWinSummary(null);
    setActiveGame(nextState);
    setSavedSession(nextState);
    await shelfRepository.saveActiveSession(nextState);
  }, [activeGame, gameEngine]);

  const handleSaveAndExitToMenu = useCallback(async () => {
    if (
      activeGame &&
      activeGame.status !== 'WON' &&
      activeGame.status !== 'LOST'
    ) {
      await shelfRepository.saveActiveSession(activeGame);
      setSavedSession(activeGame);
    } else {
      await shelfRepository.clearActiveSession();
      setSavedSession(null);
    }
    setRoute('MAIN_MENU');
  }, [activeGame]);

  const handleUpdateSettings = useCallback(
    async (nextSettings: GameSettings) => {
      setSettings(nextSettings);
      await shelfRepository.saveSettings(nextSettings);
    },
    []
  );

  const handleResetAllData = useCallback(async () => {
    const resetBundle = await shelfRepository.resetAllData();
    setPlayerStats(resetBundle.stats);
    setSettings(resetBundle.settings);
    setSavedSession(null);
    setActiveGame(null);
  }, []);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safeArea}>
        <StatusBar style="dark" backgroundColor={ShelfColors.creamBackground} />
        <View style={styles.mainViewport}>
          {route === 'SPLASH' && (
            <SplashScreen onFinishSplash={() => setRoute('MAIN_MENU')} />
          )}

          {route === 'MAIN_MENU' && (
            <MainMenuScreen
              savedSession={savedSession}
              playerStats={playerStats}
              onResumeSavedGame={handleResumeSavedGame}
              onOpenDifficultySelect={() => setRoute('DIFFICULTY')}
              onOpenStats={() => setRoute('STATS')}
              onOpenSettings={() => setRoute('SETTINGS')}
            />
          )}

          {route === 'DIFFICULTY' && (
            <DifficultyScreen
              playerStats={playerStats}
              onStartLevel={handleStartLevel}
              onBack={() => setRoute('MAIN_MENU')}
            />
          )}

          {route === 'GAME' && activeGame && (
            <GameScreen
              gameState={activeGame}
              settings={settings}
              winSummary={winSummary}
              onSelectShelfSlot={handleSelectShelfSlot}
              onUndo={handleUndo}
              onHint={handleHint}
              onTogglePause={handleTogglePause}
              onRestartLevel={handleRestartLevel}
              onNextLevel={handleNextLevel}
              onSaveAndExitToMenu={handleSaveAndExitToMenu}
              onUpdateSettings={handleUpdateSettings}
            />
          )}

          {route === 'STATS' && (
            <StatsScreen
              stats={playerStats}
              onBack={() => setRoute('MAIN_MENU')}
            />
          )}

          {route === 'SETTINGS' && (
            <SettingsScreen
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              onResetAllData={handleResetAllData}
              onBack={() => setRoute('MAIN_MENU')}
            />
          )}
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  mainViewport: {
    flex: 1,
    width: '100%',
    maxWidth: 520,
    alignSelf: 'center',
    backgroundColor: ShelfColors.creamBackground,
  },
});
