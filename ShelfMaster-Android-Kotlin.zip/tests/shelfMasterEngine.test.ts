import test from 'node:test';
import assert from 'node:assert/strict';
import { SlotManager } from '../src/domain/SlotManager.ts';
import { ScoreManager } from '../src/domain/ScoreManager.ts';
import { LevelGenerator } from '../src/domain/LevelGenerator.ts';
import { GameEngine } from '../src/domain/GameEngine.ts';
import {
  ShelfDatabaseRepository,
  type KeyValueStorageAdapter,
} from '../src/data/ShelfDatabaseRepository.ts';
import type { TraySlotItem } from '../src/domain/models.ts';

class InMemoryStorageAdapter implements KeyValueStorageAdapter {
  private store = new Map<string, string>();

  async getItem(key: string): Promise<string | null> {
    return this.store.get(key) ?? null;
  }

  async setItem(key: string, value: string): Promise<void> {
    this.store.set(key, value);
  }

  async removeItem(key: string): Promise<void> {
    this.store.delete(key);
  }
}

test('SlotManager: groups matching products and automatically clears 3 identical items', () => {
  const slotManager = new SlotManager(7);
  let slots: TraySlotItem[] = [];

  const r1 = slotManager.insertItem(slots, {
    instanceId: '1',
    productId: 'milk_bottle',
    sourceCompartmentId: 'comp_0',
    sourceColumnIndex: 0,
  });
  slots = r1.updatedSlots;
  assert.equal(slots.length, 1);
  assert.equal(r1.matchedProductId, null);

  const r2 = slotManager.insertItem(slots, {
    instanceId: '2',
    productId: 'honey_jar',
    sourceCompartmentId: 'comp_0',
    sourceColumnIndex: 1,
  });
  slots = r2.updatedSlots;
  assert.equal(slots.length, 2);

  // Insert second milk_bottle -> should group adjacent to first milk_bottle at index 1
  const r3 = slotManager.insertItem(slots, {
    instanceId: '3',
    productId: 'milk_bottle',
    sourceCompartmentId: 'comp_1',
    sourceColumnIndex: 0,
  });
  slots = r3.updatedSlots;
  assert.equal(slots.length, 3);
  assert.equal(slots[0].productId, 'milk_bottle');
  assert.equal(slots[1].productId, 'milk_bottle');
  assert.equal(slots[2].productId, 'honey_jar');

  // Insert third milk_bottle -> should automatically clear all 3 milk bottles, leaving only honey_jar
  const r4 = slotManager.insertItem(slots, {
    instanceId: '4',
    productId: 'milk_bottle',
    sourceCompartmentId: 'comp_2',
    sourceColumnIndex: 2,
  });
  slots = r4.updatedSlots;
  assert.equal(r4.matchedProductId, 'milk_bottle');
  assert.equal(r4.removedItems.length, 3);
  assert.equal(slots.length, 1);
  assert.equal(slots[0].productId, 'honey_jar');
});

test('SlotManager: triggers deadlock loss when 7 slots fill without a triplet match', () => {
  const slotManager = new SlotManager(7);
  const distinctProducts = [
    'milk_bottle',
    'honey_jar',
    'olive_oil',
    'strawberry_jam',
    'coffee_tin',
    'mint_tea',
    'orange_juice',
  ] as const;

  let slots: TraySlotItem[] = [];
  for (let i = 0; i < 7; i++) {
    const res = slotManager.insertItem(slots, {
      instanceId: `item_${i}`,
      productId: distinctProducts[i],
      sourceCompartmentId: 'comp_0',
      sourceColumnIndex: 0,
    });
    slots = res.updatedSlots;
    if (i < 6) {
      assert.equal(res.isTrayFullDeadlock, false);
    } else {
      assert.equal(res.isTrayFullDeadlock, true);
      assert.equal(slots.length, 7);
    }
  }
});

test('LevelGenerator: generates 100% solvable levels across EASY, MEDIUM, and HARD', () => {
  const generator = new LevelGenerator();
  const difficulties = ['EASY', 'MEDIUM', 'HARD'] as const;

  for (const diff of difficulties) {
    for (let level = 1; level <= 5; level++) {
      const compartments = generator.generateSolvableLevel(diff, level);
      assert.ok(compartments.length > 0);
      const isSolvable = generator.verifySolvable(compartments);
      assert.equal(
        isSolvable,
        true,
        `Expected ${diff} level ${level} to be verified solvable`
      );
    }
  }
});

test('GameEngine: supports item selection, back-layer promotion, undo, hint, and full level win', () => {
  const engine = new GameEngine();
  let state = engine.createNewGame('EASY', 1);
  assert.equal(state.status, 'PLAYING');
  const initialTotalItems = engine.countRemainingShelfItems(state.compartments);
  assert.equal(initialTotalItems, 24);

  // Request a hint and verify it identifies front-layer items
  state = engine.requestHint(state);
  assert.ok(state.activeHint !== null);
  assert.ok(state.activeHint.targetInstanceIds.length > 0);
  assert.equal(state.hintsUsed, 1);

  // Pick one item from comp_0, col 0
  const beforeLayerDepth = state.compartments[0].slots[0].layers.length;
  const moveOutcome = engine.selectShelfItem(state, 'comp_0', 0);
  state = moveOutcome.state;
  assert.equal(state.movesCount, 1);
  assert.equal(state.traySlots.length, 1);
  assert.equal(
    state.compartments[0].slots[0].layers.length,
    beforeLayerDepth - 1
  );

  // Test Undo: should restore item back to comp_0, col 0 and empty the tray
  state = engine.undoLastMove(state);
  assert.equal(state.movesCount, 0);
  assert.equal(state.traySlots.length, 0);
  assert.equal(
    state.compartments[0].slots[0].layers.length,
    beforeLayerDepth
  );
});

test('ShelfDatabaseRepository: persists and restores active game session, settings, and player stats', async () => {
  const memoryStorage = new InMemoryStorageAdapter();
  const repo = new ShelfDatabaseRepository(memoryStorage);
  const engine = new GameEngine();
  const scoreManager = new ScoreManager();

  // Create a game, make two moves, and save session
  let game = engine.createNewGame('MEDIUM', 2);
  game = engine.selectShelfItem(game, 'comp_0', 0).state;
  game = engine.selectShelfItem(game, 'comp_1', 1).state;

  await repo.saveActiveSession(game);
  const restored = await repo.loadActiveSession();
  assert.ok(restored !== null);
  assert.equal(restored.sessionId, game.sessionId);
  assert.equal(restored.difficulty, 'MEDIUM');
  assert.equal(restored.levelNumber, 2);
  assert.equal(restored.movesCount, 2);
  assert.equal(restored.traySlots.length, game.traySlots.length);

  // Save and load settings
  await repo.saveSettings({
    soundEffectsEnabled: false,
    vibrationEnabled: true,
    showBackLayerPreview: true,
    autoSortTraySlots: true,
    highContrastLabels: true,
  });
  const loadedSettings = await repo.loadSettings();
  assert.equal(loadedSettings.soundEffectsEnabled, false);
  assert.equal(loadedSettings.highContrastLabels, true);

  // Record level win and verify stats persistence
  const winSummary = scoreManager.evaluateLevelWin({
    currentScore: 1450,
    totalTriplets: 12,
    movesCount: 36,
    undosUsed: 0,
    hintsUsed: 0,
    maxComboReached: 6,
    difficulty: 'MEDIUM',
  });

  const updatedStats = await repo.recordGameWin(
    {
      ...game,
      status: 'WON',
      score: winSummary.finalScore,
      matchedTripletsCount: 12,
      movesCount: 36,
      maxComboReached: 6,
    },
    winSummary
  );

  assert.equal(updatedStats.totalGamesWon, 1);
  assert.equal(updatedStats.totalTripletsMatched, 12);
  assert.equal(updatedStats.progressByDifficulty.MEDIUM.currentLevel, 3);
  assert.equal(updatedStats.progressByDifficulty.MEDIUM.starsEarned ?? updatedStats.progressByDifficulty.MEDIUM.totalStars, 3);

  // Active session should be cleared after game completion
  const afterWinSession = await repo.loadActiveSession();
  assert.equal(afterWinSession, null);
});
