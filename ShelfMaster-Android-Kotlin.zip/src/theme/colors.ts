/**
 * Classic Artisanal Palette for Shelf Master (رتّب الرفوف)
 * Creamy parchment surfaces, rich walnut & oak wood tones,
 * classic forest green, and warm terracotta orange.
 */
export const ShelfColors = {
  // Cream & Parchment Surfaces
  creamBackground: '#FAF4E8',
  creamSurface: '#FFFDF8',
  creamElevated: '#F3E9D7',
  creamBorder: '#E2D2B8',

  // Wood & Shelf Tones
  woodDarkFrame: '#5A3821',
  woodMediumPlank: '#7D4F2D',
  woodLightTrim: '#A86E42',
  woodInteriorShadow: '#3D2414',
  woodBackLayerShade: '#2A180D',
  woodSlotTrayBg: '#E6D4BA',
  woodSlotCellBg: '#F9F2E6',
  woodSlotCellBorder: '#C7AC87',

  // Forest & Sage Green
  greenPrimary: '#2E6F40',
  greenDark: '#1E4D2B',
  greenLight: '#DCEFE2',
  greenMuted: '#538C63',

  // Warm Orange & Amber
  orangePrimary: '#D96B27',
  orangeDark: '#A84B12',
  orangeLight: '#FDE8D7',
  amberGold: '#E59A28',
  amberLight: '#FFF3D1',

  // Typography & Ink
  inkPrimary: '#2A1C12',
  inkSecondary: '#695443',
  inkMuted: '#967F6B',
  inkOnDark: '#FFFBF4',

  // Semantic States
  dangerRed: '#C83E31',
  dangerLight: '#FBE3E0',
  successGreen: '#2E6F40',
} as const;
