import { LevelGenerator } from './LevelGenerator.ts';
import {
  DIFFICULTY_CONFIGS,
  PRODUCT_CATALOG,
  type Difficulty,
  type GameSettings,
  type GameState,
  type HintSuggestion,
  type MoveSnapshot,
  type ProductId,
  type ShelfCompartment,
  type ShelfItem,
} from './models.ts';
import { ScoreManager, type LevelCompletionSummary } from './ScoreManager.ts';
import { MAX_TRAY_SLOTS, SlotManager } from './SlotManager.ts';

export interface MoveActionOutcome {
  state: GameState;
  didMatchTriplet: boolean;
  matchedProductId: ProductId | null;
  pointsEarned: number;
  completionSummary: LevelCompletionSummary | null;
}

/**
 * GameEngine coordinates all gameplay operations completely decoupled from the UI:
 * - Level creation via LevelGenerator
 * - Item selection from front shelf layer & automatic promotion of back layers
 * - 7-slot collection management via SlotManager
 * - Scoring & star evaluation via ScoreManager
 * - Undo stack restoration, Smart Hint discovery, Pause/Resume, and Serialization
 */
export class GameEngine {
  private readonly slotManager: SlotManager;
  private readonly scoreManager: ScoreManager;
  private readonly levelGenerator: LevelGenerator;

  constructor(
    slotManager = new SlotManager(MAX_TRAY_SLOTS),
    scoreManager = new ScoreManager(),
    levelGenerator = new LevelGenerator()
  ) {
    this.slotManager = slotManager;
    this.scoreManager = scoreManager;
    this.levelGenerator = levelGenerator;
  }

  public createNewGame(difficulty: Difficulty, levelNumber: number): GameState {
    const config = DIFFICULTY_CONFIGS[difficulty];
    const compartments = this.levelGenerator.generateSolvableLevel(
      difficulty,
      levelNumber
    );

    return {
      sessionId: `session_${difficulty}_${levelNumber}_${Date.now()}`,
      levelNumber,
      difficulty,
      status: 'PLAYING',
      compartments,
      traySlots: [],
      score: 0,
      comboCount: 0,
      maxComboReached: 0,
      movesCount: 0,
      matchedTripletsCount: 0,
      totalTriplets: config.totalTriplets,
      undosRemaining: config.undoLimit,
      hintsRemaining: config.hintLimit,
      undosUsed: 0,
      hintsUsed: 0,
      undoStack: [],
      activeHint: null,
      lastMatchedProductId: null,
      startedAtTimestamp: Date.now(),
    };
  }

  public selectShelfItem(
    currentState: GameState,
    compartmentId: string,
    columnIndex: number,
    settings?: Partial<GameSettings>
  ): MoveActionOutcome {
    if (currentState.status !== 'PLAYING') {
      return {
        state: currentState,
        didMatchTriplet: false,
        matchedProductId: null,
        pointsEarned: 0,
        completionSummary: null,
      };
    }

    const compIndex = currentState.compartments.findIndex(
      (c) => c.compartmentId === compartmentId
    );
    if (compIndex === -1) {
      return {
        state: currentState,
        didMatchTriplet: false,
        matchedProductId: null,
        pointsEarned: 0,
        completionSummary: null,
      };
    }

    const targetComp = currentState.compartments[compIndex];
    const targetSlot = targetComp.slots.find(
      (s) => s.columnIndex === columnIndex
    );

    if (!targetSlot || targetSlot.layers.length === 0) {
      return {
        state: currentState,
        didMatchTriplet: false,
        matchedProductId: null,
        pointsEarned: 0,
        completionSummary: null,
      };
    }

    const snapshot: MoveSnapshot = {
      compartments: this.cloneCompartments(currentState.compartments),
      traySlots: currentState.traySlots.map((t) => ({ ...t })),
      score: currentState.score,
      comboCount: currentState.comboCount,
      matchedTripletsCount: currentState.matchedTripletsCount,
      movesCount: currentState.movesCount,
    };

    const nextCompartments = this.cloneCompartments(currentState.compartments);
    const mutableSlot = nextCompartments[compIndex].slots.find(
      (s) => s.columnIndex === columnIndex
    )!;

    const pickedItem = mutableSlot.layers.shift()!;

    const groupSimilar = settings?.autoSortTraySlots ?? true;
    const insertResult = this.slotManager.insertItem(
      currentState.traySlots,
      {
        instanceId: pickedItem.instanceId,
        productId: pickedItem.productId,
        sourceCompartmentId: compartmentId,
        sourceColumnIndex: columnIndex,
      },
      groupSimilar
    );

    let nextScore = currentState.score;
    let nextCombo = currentState.comboCount;
    let nextMaxCombo = currentState.maxComboReached;
    let nextMatchedTriplets = currentState.matchedTripletsCount;
    let pointsEarned = 0;

    if (insertResult.matchedProductId) {
      const scoreUpdate = this.scoreManager.calculateMatchScore(
        currentState.score,
        currentState.comboCount,
        currentState.difficulty
      );
      nextScore = scoreUpdate.newTotalScore;
      nextCombo = scoreUpdate.newComboCount;
      nextMaxCombo = Math.max(nextMaxCombo, nextCombo);
      nextMatchedTriplets += 1;
      pointsEarned = scoreUpdate.pointsEarned;
    }

    const nextMovesCount = currentState.movesCount + 1;
    const remainingShelfItems = this.countRemainingShelfItems(nextCompartments);

    let nextStatus = currentState.status;
    let completionSummary: LevelCompletionSummary | null = null;

    if (
      remainingShelfItems === 0 &&
      insertResult.updatedSlots.length === 0
    ) {
      nextStatus = 'WON';
      completionSummary = this.scoreManager.evaluateLevelWin({
        currentScore: nextScore,
        totalTriplets: currentState.totalTriplets,
        movesCount: nextMovesCount,
        undosUsed: currentState.undosUsed,
        hintsUsed: currentState.hintsUsed,
        maxComboReached: nextMaxCombo,
        difficulty: currentState.difficulty,
      });
      nextScore = completionSummary.finalScore;
    } else if (insertResult.isTrayFullDeadlock) {
      nextStatus = 'LOST';
    }

    const nextState: GameState = {
      ...currentState,
      status: nextStatus,
      compartments: nextCompartments,
      traySlots: insertResult.updatedSlots,
      score: nextScore,
      comboCount: nextCombo,
      maxComboReached: nextMaxCombo,
      movesCount: nextMovesCount,
      matchedTripletsCount: nextMatchedTriplets,
      undoStack: [...currentState.undoStack.slice(-14), snapshot],
      activeHint: null,
      lastMatchedProductId: insertResult.matchedProductId,
    };

    return {
      state: nextState,
      didMatchTriplet: insertResult.matchedProductId !== null,
      matchedProductId: insertResult.matchedProductId,
      pointsEarned,
      completionSummary,
    };
  }

  public undoLastMove(
    currentState: GameState,
    allowEmergencyRevive: boolean = false
  ): GameState {
    if (currentState.undoStack.length === 0) {
      return currentState;
    }

    if (!allowEmergencyRevive && currentState.undosRemaining <= 0) {
      return currentState;
    }

    const previousSnapshot =
      currentState.undoStack[currentState.undoStack.length - 1];
    const nextUndoStack = currentState.undoStack.slice(0, -1);

    return {
      ...currentState,
      status: 'PLAYING',
      compartments: this.cloneCompartments(previousSnapshot.compartments),
      traySlots: previousSnapshot.traySlots.map((t) => ({ ...t })),
      score: previousSnapshot.score,
      comboCount: previousSnapshot.comboCount,
      matchedTripletsCount: previousSnapshot.matchedTripletsCount,
      movesCount: previousSnapshot.movesCount,
      undosRemaining: allowEmergencyRevive
        ? currentState.undosRemaining
        : Math.max(0, currentState.undosRemaining - 1),
      undosUsed: currentState.undosUsed + 1,
      undoStack: nextUndoStack,
      activeHint: null,
      lastMatchedProductId: null,
    };
  }

  public requestHint(currentState: GameState): GameState {
    if (
      currentState.status !== 'PLAYING' ||
      currentState.hintsRemaining <= 0
    ) {
      return currentState;
    }

    const suggestion = this.findBestHint(currentState);
    if (!suggestion) {
      return currentState;
    }

    return {
      ...currentState,
      hintsRemaining: currentState.hintsRemaining - 1,
      hintsUsed: currentState.hintsUsed + 1,
      activeHint: suggestion,
    };
  }

  public findBestHint(currentState: GameState): HintSuggestion | null {
    const frontItemsByProduct: Record<string, ShelfItem[]> = {};
    for (const comp of currentState.compartments) {
      for (const slot of comp.slots) {
        if (slot.layers.length > 0) {
          const front = slot.layers[0];
          if (!frontItemsByProduct[front.productId]) {
            frontItemsByProduct[front.productId] = [];
          }
          frontItemsByProduct[front.productId].push(front);
        }
      }
    }

    const trayCounts = this.slotManager.getCountsByProduct(
      currentState.traySlots
    );

    let bestProductId: ProductId | null = null;
    let bestScore = -1;
    let bestReason = '';

    for (const [rawPid, items] of Object.entries(frontItemsByProduct)) {
      const pid = rawPid as ProductId;
      const inTray = trayCounts[pid] ?? 0;
      const onFront = items.length;
      const productInfo = PRODUCT_CATALOG.find((p) => p.id === pid);
      const productName = productInfo?.nameAr ?? 'المنتج';

      let candidateScore = 0;
      let reason = '';

      if (inTray === 2 && onFront >= 1) {
        candidateScore = 1000 + onFront;
        reason = `اختر «${productName}» لإكمال الثلاثية فوراً وتفريغ الخانات!`;
      } else if (inTray === 1 && onFront >= 2) {
        candidateScore = 700 + onFront;
        reason = `لديك «${productName}» في الخانات وقطعتان متاحتان على الرفوف الأمامية.`;
      } else if (inTray === 0 && onFront >= 3) {
        candidateScore = 500 + onFront;
        reason = `ثلاث قطع من «${productName}» مكشوفة وجاهزة للجمع المباشر!`;
      } else if (inTray >= 1) {
        candidateScore = 250 + inTray * 50 + onFront * 20;
        reason = `تقدم في جمع «${productName}» لفتح المنتجات الخلفية.`;
      } else {
        candidateScore = 100 + onFront * 30;
        reason = `ابدأ بفرز «${productName}» لكشف الصفوف الخلفية من الرف.`;
      }

      if (candidateScore > bestScore) {
        bestScore = candidateScore;
        bestProductId = pid;
        bestReason = reason;
      }
    }

    if (!bestProductId) {
      return null;
    }

    const matchingFrontItems = frontItemsByProduct[bestProductId] ?? [];
    const neededCount = Math.max(
      1,
      3 - (trayCounts[bestProductId] ?? 0)
    );

    return {
      productId: bestProductId,
      reasonAr: bestReason,
      targetInstanceIds: matchingFrontItems
        .slice(0, neededCount)
        .map((i) => i.instanceId),
    };
  }

  public setPaused(currentState: GameState, paused: boolean): GameState {
    if (currentState.status === 'WON' || currentState.status === 'LOST') {
      return currentState;
    }
    return {
      ...currentState,
      status: paused ? 'PAUSED' : 'PLAYING',
    };
  }

  public countRemainingShelfItems(compartments: ShelfCompartment[]): number {
    let count = 0;
    for (const comp of compartments) {
      for (const slot of comp.slots) {
        count += slot.layers.length;
      }
    }
    return count;
  }

  public serializeSession(state: GameState): string {
    return JSON.stringify(state);
  }

  public deserializeSession(serialized: string): GameState | null {
    try {
      const parsed = JSON.parse(serialized) as GameState;
      if (
        !parsed ||
        !Array.isArray(parsed.compartments) ||
        !Array.isArray(parsed.traySlots)
      ) {
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  }

  private cloneCompartments(
    compartments: ShelfCompartment[]
  ): ShelfCompartment[] {
    return compartments.map((comp) => ({
      ...comp,
      slots: comp.slots.map((slot) => ({
        ...slot,
        layers: slot.layers.map((item) => ({ ...item })),
      })),
    }));
  }
}
