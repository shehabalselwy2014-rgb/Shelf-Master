import {
  DIFFICULTY_CONFIGS,
  PRODUCT_CATALOG,
  type Difficulty,
  type ProductId,
  type ShelfCompartment,
  type ShelfItem,
  type ShelfSlotStack,
  type TraySlotItem,
} from './models.ts';
import { MATCH_GROUP_SIZE, MAX_TRAY_SLOTS, SlotManager } from './SlotManager.ts';

const COMPARTMENT_TITLES_AR = [
  'الرف العلوي الأيمن',
  'الرف العلوي الأيسر',
  'رف المونة الوسطى - أ',
  'رف المونة الوسطى - ب',
  'رف العطارة والأعشاب',
  'رف الألبان والمربيات',
  'الرف السفلي الأيمن',
  'الرف السفلي الأيسر',
];

/**
 * Deterministic Pseudo-Random Generator (Mulberry32) so levels can be
 * reproducibly generated and verified by seed.
 */
class SeededRandom {
  private state: number;

  constructor(seed: number) {
    this.state = seed >>> 0;
  }

  public next(): number {
    this.state += 0x6d2b79f5;
    let t = this.state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  public nextInt(maxExclusive: number): number {
    if (maxExclusive <= 1) return 0;
    return Math.floor(this.next() * maxExclusive);
  }

  public shuffle<T>(items: T[]): T[] {
    const copy = [...items];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = this.nextInt(i + 1);
      const temp = copy[i];
      copy[i] = copy[j];
      copy[j] = temp;
    }
    return copy;
  }
}

/**
 * LevelGenerator creates structured, balanced shelf arrangements and
 * runs an actual solver verification pass (`verifySolvable`) to guarantee
 * that every single generated level can be solved within the 7-slot limit.
 */
export class LevelGenerator {
  private readonly slotManager = new SlotManager(MAX_TRAY_SLOTS);

  /**
   * Generates a guaranteed-solvable level for the specified difficulty and level number.
   */
  public generateSolvableLevel(
    difficulty: Difficulty,
    levelNumber: number
  ): ShelfCompartment[] {
    const baseSeed =
      levelNumber * 9973 +
      (difficulty === 'EASY' ? 101 : difficulty === 'MEDIUM' ? 2027 : 4099);

    for (let attempt = 0; attempt < 12; attempt++) {
      const rng = new SeededRandom(baseSeed + attempt * 313);
      const candidate = this.constructWaveBasedShelves(difficulty, rng);
      if (this.verifySolvable(candidate)) {
        return candidate;
      }
    }

    const fallbackRng = new SeededRandom(baseSeed + 77777);
    return this.constructStrictSolvableShelves(difficulty, fallbackRng);
  }

  private constructWaveBasedShelves(
    difficulty: Difficulty,
    rng: SeededRandom
  ): ShelfCompartment[] {
    const config = DIFFICULTY_CONFIGS[difficulty];
    const availableProducts = rng
      .shuffle(PRODUCT_CATALOG)
      .slice(0, config.productTypesCount)
      .map((p) => p.id);

    const triplets: ProductId[][] = [];
    for (let t = 0; t < config.totalTriplets; t++) {
      const productId = availableProducts[t % availableProducts.length];
      triplets.push([productId, productId, productId]);
    }

    const shuffledTriplets = rng.shuffle(triplets);

    const compartments: ShelfCompartment[] = [];
    for (let c = 0; c < config.compartmentCount; c++) {
      const slots: ShelfSlotStack[] = [];
      for (let col = 0; col < config.columnsPerCompartment; col++) {
        slots.push({
          columnIndex: col,
          layers: [],
        });
      }
      compartments.push({
        compartmentId: `comp_${c}`,
        rowIndex: Math.floor(c / 2),
        titleAr: COMPARTMENT_TITLES_AR[c] ?? `الرف رقم ${c + 1}`,
        slots,
      });
    }

    const allStacks: ShelfSlotStack[] = [];
    for (const comp of compartments) {
      for (const slot of comp.slots) {
        allStacks.push(slot);
      }
    }

    const waveSizeTriplets = difficulty === 'EASY' ? 4 : 3;
    let instanceCounter = 1;

    for (let i = 0; i < shuffledTriplets.length; i += waveSizeTriplets) {
      const waveTriplets = shuffledTriplets.slice(i, i + waveSizeTriplets);
      const waveItems: ShelfItem[] = [];

      for (const triplet of waveTriplets) {
        for (const productId of triplet) {
          waveItems.push({
            instanceId: `item_${instanceCounter++}_${productId}`,
            productId,
          });
        }
      }

      const shuffledWaveItems = rng.shuffle(waveItems);

      for (const item of shuffledWaveItems) {
        const eligibleStacks = allStacks.filter(
          (s) => s.layers.length < config.maxDepthLayers
        );
        let minDepth = Infinity;
        for (const s of eligibleStacks) {
          if (s.layers.length < minDepth) {
            minDepth = s.layers.length;
          }
        }
        const candidateStacks = eligibleStacks.filter(
          (s) => s.layers.length === minDepth
        );
        const chosenStack =
          candidateStacks[rng.nextInt(candidateStacks.length)] ??
          eligibleStacks[0];

        if (chosenStack) {
          chosenStack.layers.push(item);
        }
      }
    }

    this.diversifyAdjacentCompartments(compartments, rng);

    return compartments;
  }

  private diversifyAdjacentCompartments(
    compartments: ShelfCompartment[],
    rng: SeededRandom
  ): void {
    const frontSlots: ShelfSlotStack[] = [];
    for (const comp of compartments) {
      for (const slot of comp.slots) {
        if (slot.layers.length > 0) {
          frontSlots.push(slot);
        }
      }
    }

    for (let pass = 0; pass < frontSlots.length; pass++) {
      const aIndex = rng.nextInt(frontSlots.length);
      const bIndex = rng.nextInt(frontSlots.length);
      if (aIndex !== bIndex) {
        const temp = frontSlots[aIndex].layers[0];
        frontSlots[aIndex].layers[0] = frontSlots[bIndex].layers[0];
        frontSlots[bIndex].layers[0] = temp;
      }
    }
  }

  private constructStrictSolvableShelves(
    difficulty: Difficulty,
    rng: SeededRandom
  ): ShelfCompartment[] {
    const config = DIFFICULTY_CONFIGS[difficulty];
    const products = PRODUCT_CATALOG.slice(0, config.productTypesCount).map(
      (p) => p.id
    );

    const compartments: ShelfCompartment[] = [];
    for (let c = 0; c < config.compartmentCount; c++) {
      const slots: ShelfSlotStack[] = [];
      for (let col = 0; col < config.columnsPerCompartment; col++) {
        slots.push({ columnIndex: col, layers: [] });
      }
      compartments.push({
        compartmentId: `comp_${c}`,
        rowIndex: Math.floor(c / 2),
        titleAr: COMPARTMENT_TITLES_AR[c] ?? `الرف رقم ${c + 1}`,
        slots,
      });
    }

    const allStacks = compartments.flatMap((c) => c.slots);
    const tripletsPerLayer = Math.floor(allStacks.length / 3);
    let tripletsRemaining = config.totalTriplets;
    let instanceCounter = 1;
    let tripletIndex = 0;

    while (tripletsRemaining > 0) {
      const batchTriplets = Math.min(tripletsRemaining, tripletsPerLayer);
      const layerItems: ShelfItem[] = [];

      for (let t = 0; t < batchTriplets; t++) {
        const pid = products[tripletIndex % products.length];
        tripletIndex++;
        for (let k = 0; k < 3; k++) {
          layerItems.push({
            instanceId: `item_strict_${instanceCounter++}_${pid}`,
            productId: pid,
          });
        }
      }

      const shuffled = rng.shuffle(layerItems);
      const stackOrder = rng.shuffle(allStacks);
      for (let idx = 0; idx < shuffled.length; idx++) {
        stackOrder[idx].layers.push(shuffled[idx]);
      }

      tripletsRemaining -= batchTriplets;
    }

    return compartments;
  }

  public verifySolvable(compartments: ShelfCompartment[]): boolean {
    const totalCounts: Record<string, number> = {};
    let totalItems = 0;
    for (const comp of compartments) {
      for (const slot of comp.slots) {
        for (const item of slot.layers) {
          totalCounts[item.productId] = (totalCounts[item.productId] ?? 0) + 1;
          totalItems++;
        }
      }
    }

    if (totalItems === 0 || totalItems % MATCH_GROUP_SIZE !== 0) {
      return false;
    }

    for (const count of Object.values(totalCounts)) {
      if (count % MATCH_GROUP_SIZE !== 0) {
        return false;
      }
    }

    const simCompartments: ShelfCompartment[] = compartments.map((c) => ({
      ...c,
      slots: c.slots.map((s) => ({
        ...s,
        layers: [...s.layers],
      })),
    }));

    let simTray: TraySlotItem[] = [];
    let safetySteps = 0;
    const maxSteps = totalItems + 10;

    while (safetySteps < maxSteps) {
      safetySteps++;

      const frontMoves: Array<{
        compId: string;
        colIdx: number;
        item: ShelfItem;
        stackDepth: number;
        nextLayerProduct: ProductId | null;
      }> = [];

      for (const comp of simCompartments) {
        for (const slot of comp.slots) {
          if (slot.layers.length > 0) {
            frontMoves.push({
              compId: comp.compartmentId,
              colIdx: slot.columnIndex,
              item: slot.layers[0],
              stackDepth: slot.layers.length,
              nextLayerProduct: slot.layers[1]?.productId ?? null,
            });
          }
        }
      }

      if (frontMoves.length === 0) {
        return simTray.length === 0;
      }

      const trayCounts = this.slotManager.getCountsByProduct(simTray);
      const frontCounts: Record<string, number> = {};
      for (const move of frontMoves) {
        frontCounts[move.item.productId] =
          (frontCounts[move.item.productId] ?? 0) + 1;
      }

      let bestMove = frontMoves[0];
      let bestPriority = -9999;

      for (const move of frontMoves) {
        const pid = move.item.productId;
        const inTray = trayCounts[pid] ?? 0;
        const onFront = frontCounts[pid] ?? 0;

        let priority = 0;
        if (inTray === 2) {
          priority += 1000;
        } else if (inTray + onFront >= 3) {
          priority += 400 + inTray * 120 + onFront * 25;
        } else {
          priority += inTray * 60 + onFront * 15;
        }

        priority += move.stackDepth * 8;

        if (move.nextLayerProduct) {
          const nextInTray = trayCounts[move.nextLayerProduct] ?? 0;
          const nextOnFront = frontCounts[move.nextLayerProduct] ?? 0;
          if (nextInTray + nextOnFront >= 2) {
            priority += 90;
          }
        }

        if (priority > bestPriority) {
          bestPriority = priority;
          bestMove = move;
        }
      }

      const targetComp = simCompartments.find(
        (c) => c.compartmentId === bestMove.compId
      )!;
      const targetSlot = targetComp.slots[bestMove.colIdx];
      const picked = targetSlot.layers.shift()!;

      const insertResult = this.slotManager.insertItem(simTray, {
        instanceId: picked.instanceId,
        productId: picked.productId,
        sourceCompartmentId: bestMove.compId,
        sourceColumnIndex: bestMove.colIdx,
      });

      if (insertResult.isTrayFullDeadlock) {
        return false;
      }

      simTray = insertResult.updatedSlots;
    }

    return false;
  }
}
