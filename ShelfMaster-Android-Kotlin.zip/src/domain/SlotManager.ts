import type { ProductId, TraySlotItem } from './models.ts';

export const MAX_TRAY_SLOTS = 7;
export const MATCH_GROUP_SIZE = 3;

export interface SlotInsertResult {
  updatedSlots: TraySlotItem[];
  matchedProductId: ProductId | null;
  removedItems: TraySlotItem[];
  isTrayFullDeadlock: boolean;
}

/**
 * SlotManager encapsulates all logic for the 7-slot collection area:
 * - Inserting selected items (either grouped next to matching products or at the end)
 * - Detecting when 3 identical products are collected and removing them automatically
 * - Detecting loss state when all 7 slots are full with no valid 3-of-a-kind match
 */
export class SlotManager {
  public readonly maxSlots: number;

  constructor(maxSlots: number = MAX_TRAY_SLOTS) {
    this.maxSlots = maxSlots;
  }

  /**
   * Inserts an item into the 7-slot collection bar and immediately resolves
   * any 3-of-a-kind match.
   */
  public insertItem(
    currentSlots: TraySlotItem[],
    newItem: TraySlotItem,
    groupSimilarItems: boolean = true
  ): SlotInsertResult {
    if (currentSlots.length >= this.maxSlots) {
      return {
        updatedSlots: [...currentSlots],
        matchedProductId: null,
        removedItems: [],
        isTrayFullDeadlock: true,
      };
    }

    const nextSlots = [...currentSlots];

    if (groupSimilarItems) {
      let lastSameProductIndex = -1;
      for (let i = nextSlots.length - 1; i >= 0; i--) {
        if (nextSlots[i].productId === newItem.productId) {
          lastSameProductIndex = i;
          break;
        }
      }

      if (lastSameProductIndex !== -1) {
        nextSlots.splice(lastSameProductIndex + 1, 0, newItem);
      } else {
        nextSlots.push(newItem);
      }
    } else {
      nextSlots.push(newItem);
    }

    // Check if any product now has 3 matching items in the tray
    const counts = this.getCountsByProduct(nextSlots);
    let matchedProductId: ProductId | null = null;

    for (const [productId, count] of Object.entries(counts)) {
      if (count >= MATCH_GROUP_SIZE) {
        matchedProductId = productId as ProductId;
        break;
      }
    }

    if (matchedProductId) {
      const removedItems: TraySlotItem[] = [];
      const remainingSlots: TraySlotItem[] = [];

      for (const item of nextSlots) {
        if (
          item.productId === matchedProductId &&
          removedItems.length < MATCH_GROUP_SIZE
        ) {
          removedItems.push(item);
        } else {
          remainingSlots.push(item);
        }
      }

      return {
        updatedSlots: remainingSlots,
        matchedProductId,
        removedItems,
        isTrayFullDeadlock: false,
      };
    }

    const isTrayFullDeadlock = nextSlots.length >= this.maxSlots;

    return {
      updatedSlots: nextSlots,
      matchedProductId: null,
      removedItems: [],
      isTrayFullDeadlock,
    };
  }

  /**
   * Counts occurrences of each productId currently in the tray.
   */
  public getCountsByProduct(slots: TraySlotItem[]): Record<string, number> {
    const counts: Record<string, number> = {};
    for (const item of slots) {
      counts[item.productId] = (counts[item.productId] ?? 0) + 1;
    }
    return counts;
  }

  /**
   * Returns how many empty slots remain out of 7.
   */
  public getRemainingCapacity(slots: TraySlotItem[]): number {
    return Math.max(0, this.maxSlots - slots.length);
  }

  /**
   * Returns true if the tray is in danger (5 or 6 slots occupied).
   */
  public isNearCapacity(slots: TraySlotItem[]): boolean {
    return slots.length >= this.maxSlots - 2;
  }
}
