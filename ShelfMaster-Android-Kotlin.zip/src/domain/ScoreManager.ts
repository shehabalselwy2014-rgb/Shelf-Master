import { DIFFICULTY_CONFIGS, type Difficulty } from './models.ts';

export interface MatchScoreUpdate {
  pointsEarned: number;
  newTotalScore: number;
  newComboCount: number;
}

export interface LevelCompletionSummary {
  finalScore: number;
  baseScore: number;
  efficiencyBonus: number;
  cleanPlayBonus: number;
  starsEarned: 1 | 2 | 3;
}

/**
 * ScoreManager handles all scoring rules, combo progressions,
 * efficiency bonuses, and 1-3 star evaluations at level completion.
 */
export class ScoreManager {
  private static readonly BASE_TRIPLET_POINTS = 120;
  private static readonly COMBO_STEP_BONUS = 35;

  /**
   * Computes points awarded when 3 identical items are matched in the tray.
   */
  public calculateMatchScore(
    currentScore: number,
    currentCombo: number,
    difficulty: Difficulty
  ): MatchScoreUpdate {
    const nextCombo = currentCombo + 1;
    const config = DIFFICULTY_CONFIGS[difficulty];

    const rawPoints =
      ScoreManager.BASE_TRIPLET_POINTS +
      (nextCombo - 1) * ScoreManager.COMBO_STEP_BONUS;
    const pointsEarned = Math.round(rawPoints * config.scoreMultiplier);

    return {
      pointsEarned,
      newTotalScore: currentScore + pointsEarned,
      newComboCount: nextCombo,
    };
  }

  /**
   * Evaluates final level score and 1-3 star rating upon winning.
   * No timer penalty is ever applied (stress-free design).
   * Stars are awarded based on thoughtful sorting (low undo/hint reliance & combo streaks).
   */
  public evaluateLevelWin(params: {
    currentScore: number;
    totalTriplets: number;
    movesCount: number;
    undosUsed: number;
    hintsUsed: number;
    maxComboReached: number;
    difficulty: Difficulty;
  }): LevelCompletionSummary {
    const {
      currentScore,
      totalTriplets,
      movesCount,
      undosUsed,
      hintsUsed,
      maxComboReached,
      difficulty,
    } = params;

    const config = DIFFICULTY_CONFIGS[difficulty];
    const optimalMoves = totalTriplets * 3;
    const extraMoves = Math.max(0, movesCount - optimalMoves);

    const efficiencyBonus = Math.round(
      Math.max(50, 300 - extraMoves * 15) * config.scoreMultiplier
    );

    const cleanPlayBonus =
      undosUsed === 0 && hintsUsed === 0
        ? Math.round(250 * config.scoreMultiplier)
        : undosUsed + hintsUsed <= 2
        ? Math.round(120 * config.scoreMultiplier)
        : 0;

    const finalScore = currentScore + efficiencyBonus + cleanPlayBonus;

    let starsEarned: 1 | 2 | 3 = 3;
    if (undosUsed + hintsUsed > 4 || extraMoves > 9) {
      starsEarned = 1;
    } else if (undosUsed + hintsUsed > 1 || extraMoves > 3 || maxComboReached < 3) {
      starsEarned = 2;
    }

    return {
      finalScore,
      baseScore: currentScore,
      efficiencyBonus,
      cleanPlayBonus,
      starsEarned,
    };
  }
}
