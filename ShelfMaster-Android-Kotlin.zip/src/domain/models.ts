export type Difficulty = 'EASY' | 'MEDIUM' | 'HARD';

export type ProductId =
  | 'milk_bottle'
  | 'honey_jar'
  | 'olive_oil'
  | 'strawberry_jam'
  | 'coffee_tin'
  | 'mint_tea'
  | 'orange_juice'
  | 'wheat_flour'
  | 'cheese_wheel'
  | 'tomato_paste'
  | 'biscuit_box'
  | 'spice_jar';

export interface ProductCatalogItem {
  id: ProductId;
  nameAr: string;
  categoryAr: string;
  primaryColor: string;
  accentColor: string;
  badgeColor: string;
}

export const PRODUCT_CATALOG: ProductCatalogItem[] = [
  {
    id: 'milk_bottle',
    nameAr: 'قارورة حليب',
    categoryAr: 'ألبان طازجة',
    primaryColor: '#EAF4F8',
    accentColor: '#3B7EA1',
    badgeColor: '#D0E8F2',
  },
  {
    id: 'honey_jar',
    nameAr: 'جرة عسل سدر',
    categoryAr: 'عسل طبيعي',
    primaryColor: '#F6B93B',
    accentColor: '#B86B11',
    badgeColor: '#FDEBC2',
  },
  {
    id: 'olive_oil',
    nameAr: 'زيت زيتون بكر',
    categoryAr: 'زيوت بلدية',
    primaryColor: '#5B8C3E',
    accentColor: '#2E5219',
    badgeColor: '#DCECCB',
  },
  {
    id: 'strawberry_jam',
    nameAr: 'مربى التوت',
    categoryAr: 'مربيات منزلية',
    primaryColor: '#C94141',
    accentColor: '#7D1D1D',
    badgeColor: '#FAD4D4',
  },
  {
    id: 'coffee_tin',
    nameAr: 'قهوة عربية',
    categoryAr: 'محمصة تقليدية',
    primaryColor: '#6D4C3D',
    accentColor: '#C89B57',
    badgeColor: '#EBDCCB',
  },
  {
    id: 'mint_tea',
    nameAr: 'شاي بالنعناع',
    categoryAr: 'أعشاب وشاي',
    primaryColor: '#2E7D5B',
    accentColor: '#D4A84F',
    badgeColor: '#D1EFE1',
  },
  {
    id: 'orange_juice',
    nameAr: 'عصير برتقال',
    categoryAr: 'مرطبات طبيعية',
    primaryColor: '#EA7A2E',
    accentColor: '#3E7A3C',
    badgeColor: '#FDE2CC',
  },
  {
    id: 'wheat_flour',
    nameAr: 'دقيق القمح',
    categoryAr: 'حبوب ومخبوزات',
    primaryColor: '#E5CFA8',
    accentColor: '#8C6239',
    badgeColor: '#F7EFE0',
  },
  {
    id: 'cheese_wheel',
    nameAr: 'جبن القشقوان',
    categoryAr: 'أجبان معتقة',
    primaryColor: '#F2C94C',
    accentColor: '#C48A17',
    badgeColor: '#FFF3C4',
  },
  {
    id: 'tomato_paste',
    nameAr: 'معجون طماطم',
    categoryAr: 'معلبات المونة',
    primaryColor: '#D64531',
    accentColor: '#2E6F40',
    badgeColor: '#FCE0DC',
  },
  {
    id: 'biscuit_box',
    nameAr: 'علبة بسكويت',
    categoryAr: 'حلويات كلاسيكية',
    primaryColor: '#C87A4B',
    accentColor: '#5E341A',
    badgeColor: '#F5DFCF',
  },
  {
    id: 'spice_jar',
    nameAr: 'بهارات زعفران',
    categoryAr: 'عطارة وتوابل',
    primaryColor: '#D9822B',
    accentColor: '#6B2D14',
    badgeColor: '#FCE6CC',
  },
];

export interface DifficultyConfig {
  id: Difficulty;
  titleAr: string;
  subtitleAr: string;
  descriptionAr: string;
  compartmentCount: number;
  columnsPerCompartment: number;
  maxDepthLayers: number;
  productTypesCount: number;
  totalTriplets: number;
  undoLimit: number;
  hintLimit: number;
  scoreMultiplier: number;
  badgeColor: string;
}

export const DIFFICULTY_CONFIGS: Record<Difficulty, DifficultyConfig> = {
  EASY: {
    id: 'EASY',
    titleAr: 'سهل',
    subtitleAr: 'رفوف المتجر الصغير',
    descriptionAr: '٦ أصناف كلاسيكية، عمق خفيف وفرصة مثالية للاستمتاع بالترتيب الهادئ.',
    compartmentCount: 6,
    columnsPerCompartment: 3,
    maxDepthLayers: 2,
    productTypesCount: 6,
    totalTriplets: 8, // 24 items total
    undoLimit: 5,
    hintLimit: 4,
    scoreMultiplier: 1.0,
    badgeColor: '#2E6F40',
  },
  MEDIUM: {
    id: 'MEDIUM',
    titleAr: 'متوسط',
    subtitleAr: 'دكان البقالة العامر',
    descriptionAr: '٩ أصناف متنوعة مع طبقات خلفية تحتاج إلى تخطيط ذكي لخانات التجميع.',
    compartmentCount: 8,
    columnsPerCompartment: 3,
    maxDepthLayers: 2,
    productTypesCount: 9,
    totalTriplets: 12, // 36 items total
    undoLimit: 4,
    hintLimit: 3,
    scoreMultiplier: 1.5,
    badgeColor: '#D96B27',
  },
  HARD: {
    id: 'HARD',
    titleAr: 'صعب',
    subtitleAr: 'المستودع الكبير للخبراء',
    descriptionAr: '١٢ صنفاً كاملاً وعمق متعدد الطبقات يتطلب دقة عالية في إدارة الخانات السبع.',
    compartmentCount: 8,
    columnsPerCompartment: 3,
    maxDepthLayers: 3,
    productTypesCount: 12,
    totalTriplets: 16, // 48 items total
    undoLimit: 3,
    hintLimit: 3,
    scoreMultiplier: 2.0,
    badgeColor: '#8B3A2B',
  },
};

export interface ShelfItem {
  instanceId: string;
  productId: ProductId;
}

/**
 * Each position in a shelf compartment is a vertical/depth stack of items.
 * layers[0] is the front-most (selectable) item.
 * layers[1], layers[2]... are behind it and advance forward when layers[0] is picked.
 */
export interface ShelfSlotStack {
  columnIndex: number;
  layers: ShelfItem[];
}

export interface ShelfCompartment {
  compartmentId: string;
  rowIndex: number;
  titleAr: string;
  slots: ShelfSlotStack[];
}

export interface TraySlotItem {
  instanceId: string;
  productId: ProductId;
  sourceCompartmentId: string;
  sourceColumnIndex: number;
}

export type GameStatus = 'PLAYING' | 'PAUSED' | 'WON' | 'LOST';

export interface MoveSnapshot {
  compartments: ShelfCompartment[];
  traySlots: TraySlotItem[];
  score: number;
  comboCount: number;
  matchedTripletsCount: number;
  movesCount: number;
}

export interface HintSuggestion {
  productId: ProductId;
  reasonAr: string;
  targetInstanceIds: string[];
}

export interface GameState {
  sessionId: string;
  levelNumber: number;
  difficulty: Difficulty;
  status: GameStatus;
  compartments: ShelfCompartment[];
  traySlots: TraySlotItem[];
  score: number;
  comboCount: number;
  maxComboReached: number;
  movesCount: number;
  matchedTripletsCount: number;
  totalTriplets: number;
  undosRemaining: number;
  hintsRemaining: number;
  undosUsed: number;
  hintsUsed: number;
  undoStack: MoveSnapshot[];
  activeHint: HintSuggestion | null;
  lastMatchedProductId: ProductId | null;
  startedAtTimestamp: number;
}

export interface GameSettings {
  soundEffectsEnabled: boolean;
  vibrationEnabled: boolean;
  showBackLayerPreview: boolean;
  autoSortTraySlots: boolean;
  highContrastLabels: boolean;
}

export interface DifficultyProgress {
  difficulty: Difficulty;
  currentLevel: number;
  highestLevelCompleted: number;
  bestScore: number;
  totalStars: number;
  gamesWon: number;
  gamesPlayed: number;
}

export interface PlayerStats {
  totalGamesPlayed: number;
  totalGamesWon: number;
  totalGamesLost: number;
  totalTripletsMatched: number;
  totalMovesMade: number;
  highestScoreEver: number;
  longestCombo: number;
  totalUndosUsed: number;
  totalHintsUsed: number;
  progressByDifficulty: Record<Difficulty, DifficultyProgress>;
}
