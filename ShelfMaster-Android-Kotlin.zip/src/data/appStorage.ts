import AsyncStorage from '@react-native-async-storage/async-storage';
import { ShelfDatabaseRepository } from './ShelfDatabaseRepository';

export const shelfRepository = new ShelfDatabaseRepository(AsyncStorage);
