import type {
  Difficulty,
  DifficultyProgress,
  GameSettings,
  GameState,
  PlayerStats,
} from '../domain/models.ts';
import type { LevelCompletionSummary } from '../domain/ScoreManager.ts';

export interface KeyValueStorageAdapter {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

const STORAGE_KEYS = {
  ACTIVE_SESSION: '@shelf_master/room_active_session_v1',
  SETTINGS: '@shelf_master/room_settings_v1',
  STATS_AND_PROGRESS: '@shelf_master/room_stats_progress_v1',
};

export const DEFAULT_SETTINGS: GameSettings = {
  soundEffectsEnabled: true,
  vibrationEnabled: true,
  showBackLayerPreview: true,
  autoSortTraySlots: true,
  highContrastLabels: false,
};

export function createInitialProgressByDifficulty(): Record<
  Difficulty,
  DifficultyProgress
> {
  return {
    EASY: {
      difficulty: 'EASY',
      currentLevel: 1,
      highestLevelCompleted: 0,
      bestScore: 0,
      totalStars: 0,
      gamesWon: 0,
      gamesPlayed: 0,
    },
    MEDIUM: {
      difficulty: 'MEDIUM',
      currentLevel: 1,
      highestLevelCompleted: 0,
      bestScore: 0,
      totalStars: 0,
      gamesWon: 0,
      gamesPlayed: 0,
    },
    HARD: {
      difficulty: 'HARD',
      currentLevel: 1,
      highestLevelCompleted: 0,
      bestScore: 0,
      totalStars: 0,
      gamesWon: 0,
      gamesPlayed: 0,
    },
  };
}

export function createDefaultStats(): PlayerStats {
  return {
    totalGamesPlayed: 0,
    totalGamesWon: 0,
    totalGamesLost: 0,
    totalTripletsMatched: 0,
    totalMovesMade: 0,
    highestScoreEver: 0,
    longestCombo: 0,
    totalUndosUsed: 0,
    totalHintsUsed: 0,
    progressByDifficulty: createInitialProgressByDifficulty(),
  };
}

/**
 * ShelfDatabaseRepository mirrors the Android Room DAO + Repository layer:
 * - Saves and restores the active gameplay session locally offline
 * - Persists user settings (sound, vibration, back-layer preview, smart tray grouping)
 * - Tracks player progression per difficulty and lifetime statistics
 */
export class ShelfDatabaseRepository {
  private readonly storage: KeyValueStorageAdapter;

  constructor(storage: KeyValueStorageAdapter) {
    this.storage = storage;
  }

  public async saveActiveSession(state: GameState | null): Promise<void> {
    if (!state || state.status === 'WON' || state.status === 'LOST') {
      await this.storage.removeItem(STORAGE_KEYS.ACTIVE_SESSION);
      return;
    }
    const serialized = JSON.stringify(state);
    await this.storage.setItem(STORAGE_KEYS.ACTIVE_SESSION, serialized);
  }

  public async loadActiveSession(): Promise<GameState | null> {
    try {
      const raw = await this.storage.getItem(STORAGE_KEYS.ACTIVE_SESSION);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as GameState;
      if (
        !parsed ||
        !Array.isArray(parsed.compartments) ||
        !Array.isArray(parsed.traySlots)
      ) {
        return null;
      }
      return {
        ...parsed,
        status: parsed.status === 'PAUSED' ? 'PLAYING' : parsed.status,
      };
    } catch {
      return null;
    }
  }

  public async clearActiveSession(): Promise<void> {
    await this.storage.removeItem(STORAGE_KEYS.ACTIVE_SESSION);
  }

  public async loadSettings(): Promise<GameSettings> {
    try {
      const raw = await this.storage.getItem(STORAGE_KEYS.SETTINGS);
      if (!raw) return { ...DEFAULT_SETTINGS };
      return {
        ...DEFAULT_SETTINGS,
        ...(JSON.parse(raw) as Partial<GameSettings>),
      };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  public async saveSettings(settings: GameSettings): Promise<void> {
    await this.storage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }

  public async loadPlayerStats(): Promise<PlayerStats> {
    try {
      const raw = await this.storage.getItem(STORAGE_KEYS.STATS_AND_PROGRESS);
      if (!raw) return createDefaultStats();
      const parsed = JSON.parse(raw) as Partial<PlayerStats>;
      const defaults = createDefaultStats();
      return {
        ...defaults,
        ...parsed,
        progressByDifficulty: {
          ...defaults.progressByDifficulty,
          ...(parsed.progressByDifficulty ?? {}),
        },
      };
    } catch {
      return createDefaultStats();
    }
  }

  public async recordGameWin(
    finalState: GameState,
    summary: LevelCompletionSummary
  ): Promise<PlayerStats> {
    const stats = await this.loadPlayerStats();
    const diff = finalState.difficulty;
    const prevDiffProg = stats.progressByDifficulty[diff];

    const updatedDiffProgress: DifficultyProgress = {
      ...prevDiffProg,
      currentLevel: Math.max(
        prevDiffProg.currentLevel,
        finalState.levelNumber + 1
      ),
      highestLevelCompleted: Math.max(
        prevDiffProg.highestLevelCompleted,
        finalState.levelNumber
      ),
      bestScore: Math.max(prevDiffProg.bestScore, summary.finalScore),
      totalStars: prevDiffProg.totalStars + summary.starsEarned,
      gamesWon: prevDiffProg.gamesWon + 1,
      gamesPlayed: prevDiffProg.gamesPlayed + 1,
    };

    const updatedStats: PlayerStats = {
      totalGamesPlayed: stats.totalGamesPlayed + 1,
      totalGamesWon: stats.totalGamesWon + 1,
      totalGamesLost: stats.totalGamesLost,
      totalTripletsMatched:
        stats.totalTripletsMatched + finalState.matchedTripletsCount,
      totalMovesMade: stats.totalMovesMade + finalState.movesCount,
      highestScoreEver: Math.max(stats.highestScoreEver, summary.finalScore),
      longestCombo: Math.max(stats.longestCombo, finalState.maxComboReached),
      totalUndosUsed: stats.totalUndosUsed + finalState.undosUsed,
      totalHintsUsed: stats.totalHintsUsed + finalState.hintsUsed,
      progressByDifficulty: {
        ...stats.progressByDifficulty,
        [diff]: updatedDiffProgress,
      },
    };

    await this.storage.setItem(
      STORAGE_KEYS.STATS_AND_PROGRESS,
      JSON.stringify(updatedStats)
    );
    await this.clearActiveSession();
    return updatedStats;
  }

  public async recordGameLoss(finalState: GameState): Promise<PlayerStats> {
    const stats = await this.loadPlayerStats();
    const diff = finalState.difficulty;
    const prevDiffProg = stats.progressByDifficulty[diff];

    const updatedStats: PlayerStats = {
      totalGamesPlayed: stats.totalGamesPlayed + 1,
      totalGamesWon: stats.totalGamesWon,
      totalGamesLost: stats.totalGamesLost + 1,
      totalTripletsMatched:
        stats.totalTripletsMatched + finalState.matchedTripletsCount,
      totalMovesMade: stats.totalMovesMade + finalState.movesCount,
      highestScoreEver: Math.max(stats.highestScoreEver, finalState.score),
      longestCombo: Math.max(stats.longestCombo, finalState.maxComboReached),
      totalUndosUsed: stats.totalUndosUsed + finalState.undosUsed,
      totalHintsUsed: stats.totalHintsUsed + finalState.hintsUsed,
      progressByDifficulty: {
        ...stats.progressByDifficulty,
        [diff]: {
          ...prevDiffProg,
          gamesPlayed: prevDiffProg.gamesPlayed + 1,
        },
      },
    };

    await this.storage.setItem(
      STORAGE_KEYS.STATS_AND_PROGRESS,
      JSON.stringify(updatedStats)
    );
    await this.clearActiveSession();
    return updatedStats;
  }

  public async resetAllData(): Promise<{
    stats: PlayerStats;
    settings: GameSettings;
  }> {
    await this.storage.removeItem(STORAGE_KEYS.ACTIVE_SESSION);
    await this.storage.removeItem(STORAGE_KEYS.STATS_AND_PROGRESS);
    await this.storage.removeItem(STORAGE_KEYS.SETTINGS);
    return {
      stats: createDefaultStats(),
      settings: { ...DEFAULT_SETTINGS },
    };
  }
}
