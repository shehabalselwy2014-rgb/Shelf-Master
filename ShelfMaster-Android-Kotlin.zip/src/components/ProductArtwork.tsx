import React from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, {
  Circle,
  Defs,
  Ellipse,
  G,
  LinearGradient,
  Path,
  Polygon,
  Rect,
  Stop,
} from 'react-native-svg';
import type { ProductId } from '../domain/models';

interface ProductArtworkProps {
  productId: ProductId;
  size?: number;
  dimmed?: boolean;
}

/**
 * Original lightweight vector illustrations for all 12 grocery products.
 * Zero emojis used — crisp custom SVG vector shapes optimized for smooth rendering
 * on all Android devices including low/mid-range hardware.
 */
export const ProductArtwork: React.FC<ProductArtworkProps> = React.memo(
  ({ productId, size = 54, dimmed = false }) => {
    const renderVectorProduct = () => {
      switch (productId) {
        case 'milk_bottle':
          return (
            <G>
              {/* Bottle shadow */}
              <Ellipse cx="32" cy="58" rx="15" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Glass bottle body */}
              <Path
                d="M23 11 H41 L42 20 L47 28 V52 C47 55.5 44.5 57 41 57 H23 C19.5 57 17 55.5 17 52 V28 L22 20 Z"
                fill="#FFFFFF"
                stroke="#3B7EA1"
                strokeWidth="2.2"
              />
              {/* Milk fill */}
              <Path
                d="M19 30 H45 V51 C45 53.5 43.5 55 41 55 H23 C20.5 55 19 53.5 19 51 Z"
                fill="#F3F9FC"
              />
              {/* Blue label band */}
              <Rect x="18" y="34" width="28" height="12" fill="#3B7EA1" />
              {/* White milk drop emblem */}
              <Path
                d="M32 36.5 C32 36.5 35.5 40.5 35.5 42.5 C35.5 44.4 33.9 45.5 32 45.5 C30.1 45.5 28.5 44.4 28.5 42.5 C28.5 40.5 32 36.5 32 36.5 Z"
                fill="#FFFDF8"
              />
              {/* Bottle cap */}
              <Rect
                x="21"
                y="7"
                width="22"
                height="5"
                rx="2.5"
                fill="#296485"
              />
              {/* Glass highlight */}
              <Path
                d="M22 29 V50"
                stroke="#CFE6F2"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </G>
          );

        case 'honey_jar':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="17" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Hexagonal jar body */}
              <Polygon
                points="20,17 44,17 50,27 50,49 44,57 20,57 14,49 14,27"
                fill="#F5A623"
                stroke="#8F4F06"
                strokeWidth="2.2"
              />
              {/* Golden inner honey glow */}
              <Polygon
                points="22,22 42,22 46,29 46,47 42,53 22,53 18,47 18,29"
                fill="#FFC845"
              />
              {/* Cream hexagon label */}
              <Polygon
                points="25,30 39,30 43,37 39,45 25,45 21,37"
                fill="#FFF8E6"
                stroke="#B86B11"
                strokeWidth="1.6"
              />
              {/* Honeycomb cell icon */}
              <Polygon
                points="32,33 36,35.2 36,39.5 32,41.7 28,39.5 28,35.2"
                fill="#E08A1E"
              />
              {/* Wooden ribbed lid */}
              <Rect
                x="19"
                y="10"
                width="26"
                height="7"
                rx="3"
                fill="#8B5A36"
                stroke="#5A3821"
                strokeWidth="1.8"
              />
              <Path d="M24 11 V16 M32 11 V16 M40 11 V16" stroke="#5A3821" strokeWidth="1.5" />
            </G>
          );

        case 'olive_oil':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="14" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Cork */}
              <Rect x="28" y="6" width="8" height="6" rx="1.5" fill="#B58352" stroke="#6E472B" strokeWidth="1.5" />
              {/* Bottle neck & body */}
              <Path
                d="M27 12 H37 V19 L45 26 V52 C45 55 42.5 57 39.5 57 H24.5 C21.5 57 19 55 19 52 V26 L27 19 Z"
                fill="#4D7C32"
                stroke="#254214"
                strokeWidth="2.2"
              />
              {/* Gold neck collar */}
              <Rect x="27" y="15" width="10" height="3.5" fill="#E5B143" />
              {/* Cream label */}
              <Rect
                x="22"
                y="30"
                width="20"
                height="19"
                rx="3"
                fill="#FCF6E6"
                stroke="#C7A046"
                strokeWidth="1.5"
              />
              {/* Olive emblem */}
              <Ellipse cx="32" cy="40" rx="4" ry="5" fill="#3B6922" />
              <Path d="M28 35 Q32 31 37 35" stroke="#5B8C3E" strokeWidth="1.8" fill="none" />
              {/* Highlight */}
              <Path d="M22 27 V51" stroke="#7FA862" strokeWidth="1.8" strokeLinecap="round" />
            </G>
          );

        case 'strawberry_jam':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="16" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Rounded jam jar */}
              <Rect
                x="15"
                y="18"
                width="34"
                height="39"
                rx="9"
                fill="#C93B3B"
                stroke="#781818"
                strokeWidth="2.2"
              />
              {/* Inner berry highlight */}
              <Rect x="18" y="23" width="28" height="30" rx="6" fill="#DE4E4E" />
              {/* Cream oval label */}
              <Ellipse
                cx="32"
                cy="39"
                rx="11"
                ry="8.5"
                fill="#FFF9F0"
                stroke="#8F2424"
                strokeWidth="1.5"
              />
              {/* Berry icon on label */}
              <Path
                d="M32 44 C28.5 44 27 39.5 28.5 36.5 C30 34.5 34 34.5 35.5 36.5 C37 39.5 35.5 44 32 44 Z"
                fill="#C93B3B"
              />
              <Path d="M29.5 35 L32 36.5 L34.5 35" stroke="#2E6F40" strokeWidth="1.8" strokeLinecap="round" />
              {/* Cloth ruffled lid cover */}
              <Path
                d="M13 18 Q18 11 32 11 Q46 11 51 18 L48 22 Q40 19 32 21 Q24 19 16 22 Z"
                fill="#F7E4DC"
                stroke="#A83232"
                strokeWidth="1.8"
              />
              <Path d="M16 18 H48" stroke="#D96B27" strokeWidth="2" />
            </G>
          );

        case 'coffee_tin':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="16" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Cylindrical coffee canister */}
              <Rect
                x="16"
                y="13"
                width="32"
                height="44"
                rx="4"
                fill="#5E3C2C"
                stroke="#361F14"
                strokeWidth="2.2"
              />
              {/* Brass top & bottom rims */}
              <Rect x="15" y="10" width="34" height="5" rx="2" fill="#D4A349" stroke="#7A5417" strokeWidth="1.5" />
              <Rect x="16" y="53" width="32" height="4" rx="1.5" fill="#D4A349" />
              {/* Traditional arch label */}
              <Path
                d="M22 48 V30 C22 24 26.5 20 32 20 C37.5 20 42 24 42 30 V48 Z"
                fill="#FAF0DC"
                stroke="#C89B57"
                strokeWidth="1.6"
              />
              {/* Roasted coffee bean icon */}
              <Ellipse cx="32" cy="35" rx="5.5" ry="7" fill="#4A2C1D" />
              <Path d="M32 29 Q30 35 32 41" stroke="#FAF0DC" strokeWidth="1.5" fill="none" />
            </G>
          );

        case 'mint_tea':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="16" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Tea caddy box */}
              <Rect
                x="16"
                y="16"
                width="32"
                height="41"
                rx="4"
                fill="#246B4B"
                stroke="#133D29"
                strokeWidth="2.2"
              />
              {/* Domed gold cap */}
              <Path
                d="M25 16 C25 11 39 11 39 16 Z"
                fill="#E0B14C"
                stroke="#856117"
                strokeWidth="1.6"
              />
              <Rect x="18" y="15" width="28" height="3" fill="#E0B14C" />
              {/* Cream & gold ornate frame */}
              <Rect
                x="21"
                y="23"
                width="22"
                height="27"
                rx="3"
                fill="#F7F4E8"
                stroke="#D4A84F"
                strokeWidth="1.8"
              />
              {/* Mint leaf double motif */}
              <Path
                d="M32 43 C27 41 26 35 32 30 C38 35 37 41 32 43 Z"
                fill="#2E8B57"
              />
              <Path d="M32 32 V43" stroke="#D1EFE1" strokeWidth="1.4" />
            </G>
          );

        case 'orange_juice':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="15" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Green cap */}
              <Rect x="25" y="7" width="14" height="5" rx="2" fill="#2E6F40" />
              {/* Carafe bottle */}
              <Path
                d="M26 12 H38 L40 20 C45 24 47 29 47 36 V51 C47 55 44 57 40 57 H24 C20 57 17 55 17 51 V36 C17 29 19 24 24 20 Z"
                fill="#F58220"
                stroke="#9E4709"
                strokeWidth="2.2"
              />
              {/* Bright orange inner tone */}
              <Path
                d="M20 33 H44 V50 C44 53 42 54.5 39 54.5 H25 C22 54.5 20 53 20 50 Z"
                fill="#FFA033"
              />
              {/* Label badge with orange slice */}
              <Circle cx="32" cy="39" r="9" fill="#FFFDF7" stroke="#BA5812" strokeWidth="1.5" />
              <Circle cx="32" cy="39" r="6" fill="#F58220" />
              <Circle cx="32" cy="39" r="1.5" fill="#FFFDF7" />
              <Path d="M32 33 V45 M26 39 H38" stroke="#FFFDF7" strokeWidth="1.2" />
            </G>
          );

        case 'wheat_flour':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="18" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Tied sack top */}
              <Path
                d="M23 9 L27 17 H37 L41 9 L35 12 L32 8 L29 12 Z"
                fill="#DFC69E"
                stroke="#7D5B36"
                strokeWidth="1.8"
              />
              {/* Flour sack body */}
              <Path
                d="M25 17 H39 C45 22 49 32 48 49 C48 54.5 44.5 57 39 57 H25 C19.5 57 16 54.5 16 49 C15 32 19 22 25 17 Z"
                fill="#EFE1C6"
                stroke="#7D5B36"
                strokeWidth="2.2"
              />
              {/* Terracotta cord tie */}
              <Rect x="24" y="15.5" width="16" height="3.5" rx="1.7" fill="#C85A28" />
              {/* Center emblem circle */}
              <Circle cx="32" cy="38" r="10" fill="#FFFDF8" stroke="#B89361" strokeWidth="1.5" />
              {/* Golden wheat spike */}
              <Path d="M32 45 V31" stroke="#B87A1E" strokeWidth="2" strokeLinecap="round" />
              <Ellipse cx="29.5" cy="34" rx="2" ry="1.2" fill="#E09F2D" />
              <Ellipse cx="34.5" cy="34" rx="2" ry="1.2" fill="#E09F2D" />
              <Ellipse cx="29.5" cy="38" rx="2" ry="1.2" fill="#E09F2D" />
              <Ellipse cx="34.5" cy="38" rx="2" ry="1.2" fill="#E09F2D" />
            </G>
          );

        case 'cheese_wheel':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="19" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Waxed cheese cylinder/wedge */}
              <Path
                d="M13 28 C13 21 51 21 51 28 V47 C51 54 13 54 13 47 Z"
                fill="#F4C430"
                stroke="#9C6B0C"
                strokeWidth="2.2"
              />
              {/* Top face of cheese wheel */}
              <Ellipse
                cx="32"
                cy="27"
                rx="19"
                ry="7"
                fill="#FFE066"
                stroke="#9C6B0C"
                strokeWidth="2"
              />
              {/* Red/Terracotta traditional wax band */}
              <Path
                d="M14 36 Q32 41 50 36 V43 Q32 48 14 43 Z"
                fill="#C84B31"
              />
              {/* Cheese holes */}
              <Circle cx="24" cy="26" r="2.2" fill="#D99B1A" />
              <Circle cx="36" cy="28" r="2.6" fill="#D99B1A" />
              <Circle cx="27" cy="48" r="2" fill="#D99B1A" />
              <Circle cx="39" cy="46" r="1.8" fill="#D99B1A" />
            </G>
          );

        case 'tomato_paste':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="16" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Tin can body */}
              <Rect
                x="16"
                y="13"
                width="32"
                height="44"
                rx="3"
                fill="#D13B27"
                stroke="#7A1C10"
                strokeWidth="2.2"
              />
              {/* Metallic top and bottom rims */}
              <Rect x="15" y="11" width="34" height="4" rx="1.5" fill="#CBD2D6" stroke="#6E787D" strokeWidth="1.4" />
              <Rect x="15" y="54" width="34" height="3.5" rx="1.5" fill="#CBD2D6" stroke="#6E787D" strokeWidth="1.4" />
              {/* Cream middle label */}
              <Rect x="17" y="23" width="30" height="22" fill="#FFF9EE" />
              {/* Red ripe tomato icon */}
              <Circle cx="32" cy="35" r="7" fill="#D63622" />
              {/* Green tomato stem/leaves */}
              <Path
                d="M28 28 L32 30 L36 28 M32 26 V30"
                stroke="#2E6F40"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </G>
          );

        case 'biscuit_box':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="18" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Vintage cookie box */}
              <Rect
                x="13"
                y="17"
                width="38"
                height="39"
                rx="5"
                fill="#C47340"
                stroke="#5E3114"
                strokeWidth="2.2"
              />
              {/* Overhanging tin lid */}
              <Rect
                x="11"
                y="12"
                width="42"
                height="7"
                rx="3"
                fill="#7D4422"
                stroke="#47230D"
                strokeWidth="1.8"
              />
              {/* Cream diamond/plaque */}
              <Rect
                x="19"
                y="24"
                width="26"
                height="24"
                rx="6"
                fill="#FFF8EB"
                stroke="#8F4E24"
                strokeWidth="1.5"
              />
              {/* Golden butter biscuit inside */}
              <Circle cx="32" cy="36" r="7.5" fill="#E5A247" stroke="#9E6216" strokeWidth="1.5" />
              <Circle cx="29.5" cy="34" r="1" fill="#7D4422" />
              <Circle cx="34.5" cy="34" r="1" fill="#7D4422" />
              <Circle cx="29.5" cy="38" r="1" fill="#7D4422" />
              <Circle cx="34.5" cy="38" r="1" fill="#7D4422" />
            </G>
          );

        case 'spice_jar':
          return (
            <G>
              <Ellipse cx="32" cy="58" rx="14" ry="3" fill="rgba(0,0,0,0.14)" />
              {/* Tapered cork stopper */}
              <Polygon
                points="25,7 39,7 37,15 27,15"
                fill="#B88454"
                stroke="#634122"
                strokeWidth="1.6"
              />
              {/* Apothecary glass jar */}
              <Path
                d="M24 15 H40 V20 L46 26 V51 C46 54.5 43.5 57 40 57 H24 C20.5 57 18 54.5 18 51 V26 L24 20 Z"
                fill="#FDF6EA"
                stroke="#7A3B12"
                strokeWidth="2.2"
              />
              {/* Rich saffron/spice mound inside jar */}
              <Path
                d="M20 35 Q26 28 32 31 Q38 27 44 35 V51 C44 53.5 42.5 55 40 55 H24 C21.5 55 20 53.5 20 51 Z"
                fill="#DB6A1D"
              />
              {/* Traditional spice tag */}
              <Rect
                x="23"
                y="34"
                width="18"
                height="13"
                rx="2.5"
                fill="#FFF9ED"
                stroke="#6E2C0E"
                strokeWidth="1.5"
              />
              {/* Saffron threads motif */}
              <Path
                d="M29 43 Q32 38 35 37 M30 37 Q32 40 35 43"
                stroke="#C83E31"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </G>
          );
      }
    };

    return (
      <View style={[styles.wrapper, { width: size, height: size }]}>
        <Svg width={size} height={size} viewBox="0 0 64 62">
          <Defs>
            <LinearGradient id="dimOverlay" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor="#2A180D" stopOpacity="0.55" />
              <Stop offset="1" stopColor="#1A0E07" stopOpacity="0.68" />
            </LinearGradient>
          </Defs>
          {renderVectorProduct()}
          {dimmed && (
            <Rect
              x="8"
              y="4"
              width="48"
              height="56"
              rx="10"
              fill="url(#dimOverlay)"
            />
          )}
        </Svg>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
