import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import {
  PRODUCT_CATALOG,
  type ProductId,
  type TraySlotItem,
} from '../domain/models';
import { MAX_TRAY_SLOTS } from '../domain/SlotManager';
import { ShelfColors } from '../theme/colors';
import { ProductArtwork } from './ProductArtwork';

interface CollectionTrayBarProps {
  traySlots: TraySlotItem[];
  lastMatchedProductId: ProductId | null;
}

export const CollectionTrayBar: React.FC<CollectionTrayBarProps> = React.memo(
  ({ traySlots, lastMatchedProductId }) => {
    const remainingSlots = Math.max(0, MAX_TRAY_SLOTS - traySlots.length);
    const isDangerZone = remainingSlots <= 2 && remainingSlots > 0;

    // Count items per product to highlight pairs (2/3 ready to match)
    const countsByProduct: Record<string, number> = {};
    for (const item of traySlots) {
      countsByProduct[item.productId] =
        (countsByProduct[item.productId] ?? 0) + 1;
    }

    const lastMatchedCatalog = lastMatchedProductId
      ? PRODUCT_CATALOG.find((p) => p.id === lastMatchedProductId)
      : null;

    const slotIndices = Array.from({ length: MAX_TRAY_SLOTS }, (_, i) => i);

    return (
      <View style={styles.trayOuterWrapper}>
        {/* Status Header Row above the 7 slots */}
        <View style={styles.trayHeaderRow}>
          <View style={styles.trayTitleBadge}>
            <Text style={styles.trayTitleText}>منطقة التجميع (٧ خانات)</Text>
          </View>

          {lastMatchedCatalog ? (
            <View style={styles.matchFeedbackPill}>
              <Text style={styles.matchFeedbackText}>
                تمت مطابقة ٣ من «{lastMatchedCatalog.nameAr}»!
              </Text>
            </View>
          ) : (
            <View
              style={[
                styles.capacityPill,
                isDangerZone && styles.capacityPillDanger,
              ]}
            >
              <Text
                style={[
                  styles.capacityPillText,
                  isDangerZone && styles.capacityPillTextDanger,
                ]}
              >
                {remainingSlots === 0
                  ? 'الخانات ممتلئة!'
                  : isDangerZone
                  ? `تنبيه: تبقّت ${remainingSlots} خانات فقط`
                  : `الخانات المشغولة: ${traySlots.length} / ${MAX_TRAY_SLOTS}`}
              </Text>
            </View>
          )}
        </View>

        {/* 7-Slot Wooden Tray Container (RTL order right-to-left) */}
        <View
          style={[
            styles.woodenTrayDock,
            isDangerZone && styles.woodenTrayDockDanger,
          ]}
        >
          <View style={styles.slotsRowRtl}>
            {slotIndices.map((slotIndex) => {
              const slotItem = traySlots[slotIndex] ?? null;
              const isPairReady =
                slotItem !== null &&
                (countsByProduct[slotItem.productId] ?? 0) === 2;

              return (
                <View
                  key={slotIndex}
                  style={[
                    styles.slotBox,
                    slotItem && styles.slotBoxOccupied,
                    isPairReady && styles.slotBoxPairReady,
                  ]}
                >
                  {slotItem ? (
                    <View style={styles.slotItemContent}>
                      <ProductArtwork
                        productId={slotItem.productId}
                        size={40}
                      />
                      {isPairReady && (
                        <View style={styles.pairReadyDot} />
                      )}
                    </View>
                  ) : (
                    <Text style={styles.emptySlotNumber}>{slotIndex + 1}</Text>
                  )}
                </View>
              );
            })}
          </View>
        </View>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  trayOuterWrapper: {
    paddingHorizontal: 12,
    paddingTop: 6,
    paddingBottom: 8,
    backgroundColor: ShelfColors.creamElevated,
    borderTopWidth: 2,
    borderTopColor: ShelfColors.creamBorder,
  },
  trayHeaderRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  trayTitleBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  trayTitleText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  capacityPill: {
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
  },
  capacityPillDanger: {
    backgroundColor: ShelfColors.dangerLight,
    borderColor: ShelfColors.dangerRed,
  },
  capacityPillText: {
    fontSize: 11,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
  },
  capacityPillTextDanger: {
    color: ShelfColors.dangerRed,
  },
  matchFeedbackPill: {
    backgroundColor: ShelfColors.greenLight,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: ShelfColors.greenPrimary,
  },
  matchFeedbackText: {
    fontSize: 11,
    fontWeight: '800',
    color: ShelfColors.greenDark,
  },
  woodenTrayDock: {
    backgroundColor: ShelfColors.woodDarkFrame,
    borderRadius: 14,
    padding: 7,
    borderWidth: 2.5,
    borderColor: ShelfColors.woodLightTrim,
    shadowColor: '#2A180D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  woodenTrayDockDanger: {
    borderColor: ShelfColors.dangerRed,
  },
  slotsRowRtl: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  slotBox: {
    flex: 1,
    height: 52,
    marginHorizontal: 2,
    borderRadius: 9,
    backgroundColor: ShelfColors.woodSlotCellBg,
    borderWidth: 1.5,
    borderColor: ShelfColors.woodSlotCellBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotBoxOccupied: {
    backgroundColor: ShelfColors.creamSurface,
    borderColor: ShelfColors.woodLightTrim,
  },
  slotBoxPairReady: {
    backgroundColor: ShelfColors.amberLight,
    borderColor: ShelfColors.orangePrimary,
    borderWidth: 2,
  },
  slotItemContent: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  pairReadyDot: {
    position: 'absolute',
    top: -2,
    left: -2,
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: ShelfColors.orangePrimary,
  },
  emptySlotNumber: {
    fontSize: 12,
    fontWeight: '700',
    color: ShelfColors.woodSlotCellBorder,
  },
});
