import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import {
  PRODUCT_CATALOG,
  type HintSuggestion,
  type ShelfCompartment,
} from '../domain/models';
import { ShelfColors } from '../theme/colors';
import { ProductArtwork } from './ProductArtwork';

interface ShelfCompartmentViewProps {
  compartment: ShelfCompartment;
  showBackLayerPreview: boolean;
  highContrastLabels: boolean;
  activeHint: HintSuggestion | null;
  onSelectSlot: (compartmentId: string, columnIndex: number) => void;
}

export const ShelfCompartmentView: React.FC<ShelfCompartmentViewProps> =
  React.memo(
    ({
      compartment,
      showBackLayerPreview,
      highContrastLabels,
      activeHint,
      onSelectSlot,
    }) => {
      return (
        <View style={styles.compartmentContainer}>
          {/* Top wooden molding header */}
          <View style={styles.topWoodTrim}>
            <Text style={styles.compartmentTitle}>{compartment.titleAr}</Text>
          </View>

          {/* Deep wooden recessed interior */}
          <View style={styles.recessedBay}>
            <View style={styles.slotsRow}>
              {compartment.slots.map((slot) => {
                const frontItem = slot.layers[0] ?? null;
                const backItem = slot.layers[1] ?? null;
                const extraLayersCount = Math.max(0, slot.layers.length - 1);

                const isHintHighlighted =
                  frontItem !== null &&
                  activeHint !== null &&
                  (activeHint.targetInstanceIds.includes(
                    frontItem.instanceId
                  ) ||
                    activeHint.productId === frontItem.productId);

                const catalogInfo = frontItem
                  ? PRODUCT_CATALOG.find((p) => p.id === frontItem.productId)
                  : null;

                return (
                  <View key={slot.columnIndex} style={styles.slotColumn}>
                    {/* Back layer silhouette peeking in shelf depth */}
                    {showBackLayerPreview && backItem && (
                      <View style={styles.backLayerPreview} pointerEvents="none">
                        <ProductArtwork
                          productId={backItem.productId}
                          size={40}
                          dimmed={true}
                        />
                      </View>
                    )}

                    {/* Depth layer count pill (if items exist behind front item) */}
                    {extraLayersCount > 0 && (
                      <View style={styles.depthBadge} pointerEvents="none">
                        <Text style={styles.depthBadgeText}>
                          +{extraLayersCount}
                        </Text>
                      </View>
                    )}

                    {/* Selectable Front-Layer Product */}
                    {frontItem ? (
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel={`اختيار ${
                          catalogInfo?.nameAr ?? 'منتج'
                        } من ${compartment.titleAr}`}
                        onPress={() =>
                          onSelectSlot(
                            compartment.compartmentId,
                            slot.columnIndex
                          )
                        }
                        style={({ pressed }) => [
                          styles.frontItemButton,
                          isHintHighlighted && styles.hintHighlightedItem,
                          pressed && styles.frontItemPressed,
                        ]}
                      >
                        <ProductArtwork
                          productId={frontItem.productId}
                          size={54}
                        />
                        {highContrastLabels && catalogInfo && (
                          <View style={styles.highContrastTag}>
                            <Text
                              style={styles.highContrastTagText}
                              numberOfLines={1}
                            >
                              {catalogInfo.nameAr}
                            </Text>
                          </View>
                        )}
                      </Pressable>
                    ) : (
                      <View style={styles.emptySlotSpot} />
                    )}
                  </View>
                );
              })}
            </View>
          </View>

          {/* Bottom sturdy wooden shelf plank */}
          <View style={styles.bottomPlank}>
            <View style={styles.plankHighlight} />
          </View>
        </View>
      );
    }
  );

const styles = StyleSheet.create({
  compartmentContainer: {
    flex: 1,
    minWidth: 152,
    marginHorizontal: 5,
    marginBottom: 12,
    borderRadius: 12,
    backgroundColor: ShelfColors.woodDarkFrame,
    borderWidth: 2,
    borderColor: ShelfColors.woodDarkFrame,
    overflow: 'hidden',
    shadowColor: '#2A180D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.22,
    shadowRadius: 5,
    elevation: 4,
  },
  topWoodTrim: {
    backgroundColor: ShelfColors.woodMediumPlank,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderBottomWidth: 1.5,
    borderBottomColor: ShelfColors.woodLightTrim,
    alignItems: 'center',
  },
  compartmentTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: ShelfColors.creamSurface,
    textAlign: 'center',
  },
  recessedBay: {
    backgroundColor: ShelfColors.woodInteriorShadow,
    paddingTop: 14,
    paddingBottom: 4,
    paddingHorizontal: 6,
    minHeight: 88,
    justifyContent: 'flex-end',
  },
  slotsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
  },
  slotColumn: {
    width: 52,
    height: 74,
    alignItems: 'center',
    justifyContent: 'flex-end',
    position: 'relative',
  },
  backLayerPreview: {
    position: 'absolute',
    top: 0,
    right: 2,
    opacity: 0.72,
    transform: [{ scale: 0.84 }],
  },
  depthBadge: {
    position: 'absolute',
    top: 0,
    left: 1,
    backgroundColor: 'rgba(217, 107, 39, 0.92)',
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 8,
    zIndex: 5,
  },
  depthBadgeText: {
    color: '#FFFDF8',
    fontSize: 9,
    fontWeight: '800',
  },
  frontItemButton: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: 2,
    borderRadius: 10,
    zIndex: 3,
  },
  frontItemPressed: {
    transform: [{ scale: 0.91 }, { translateY: -3 }],
  },
  hintHighlightedItem: {
    backgroundColor: 'rgba(232, 155, 45, 0.28)',
    borderWidth: 2,
    borderColor: ShelfColors.amberGold,
    shadowColor: ShelfColors.amberGold,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: 6,
  },
  highContrastTag: {
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 4,
    marginTop: -3,
    borderWidth: 1,
    borderColor: ShelfColors.woodLightTrim,
    maxWidth: 50,
  },
  highContrastTagText: {
    fontSize: 8,
    fontWeight: '700',
    color: ShelfColors.inkPrimary,
    textAlign: 'center',
  },
  emptySlotSpot: {
    width: 34,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    marginBottom: 4,
  },
  bottomPlank: {
    height: 12,
    backgroundColor: ShelfColors.woodMediumPlank,
    borderTopWidth: 2,
    borderTopColor: ShelfColors.woodLightTrim,
    justifyContent: 'flex-start',
  },
  plankHighlight: {
    height: 3,
    backgroundColor: 'rgba(255, 244, 224, 0.22)',
  },
});
