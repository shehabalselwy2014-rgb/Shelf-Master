import React, { useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { ProductArtwork } from '../components/ProductArtwork';
import {
  DIFFICULTY_CONFIGS,
  PRODUCT_CATALOG,
  type GameState,
  type PlayerStats,
} from '../domain/models';
import { ShelfColors } from '../theme/colors';

interface MainMenuScreenProps {
  savedSession: GameState | null;
  playerStats: PlayerStats;
  onResumeSavedGame: () => void;
  onOpenDifficultySelect: () => void;
  onOpenStats: () => void;
  onOpenSettings: () => void;
}

export const MainMenuScreen: React.FC<MainMenuScreenProps> = ({
  savedSession,
  playerStats,
  onResumeSavedGame,
  onOpenDifficultySelect,
  onOpenStats,
  onOpenSettings,
}) => {
  const [showGuideModal, setShowGuideModal] = useState(false);

  const totalStars =
    playerStats.progressByDifficulty.EASY.totalStars +
    playerStats.progressByDifficulty.MEDIUM.totalStars +
    playerStats.progressByDifficulty.HARD.totalStars;

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={false}
    >
      {/* Top Classic Wooden Signboard Header */}
      <View style={styles.heroBanner}>
        <View style={styles.heroSignHeader}>
          <View style={styles.offlineBadge}>
            <Ionicons
              name="checkmark-circle"
              size={14}
              color={ShelfColors.greenLight}
            />
            <Text style={styles.offlineBadgeText}>يعمل بالكامل دون إنترنت</Text>
          </View>
          <View style={styles.noTimerBadge}>
            <Ionicons
              name="leaf"
              size={14}
              color={ShelfColors.amberLight}
            />
            <Text style={styles.noTimerBadgeText}>بدون مؤقت إجباري</Text>
          </View>
        </View>

        <Text style={styles.heroTitleAr}>رتّب الرفوف</Text>
        <Text style={styles.heroSubtitleAr}>
          Shelf Master • ألغاز فرز المنتجات الكلاسيكية
        </Text>

        {/* Mini Shelf Display */}
        <View style={styles.miniShelfRack}>
          <View style={styles.miniShelfRow}>
            <ProductArtwork productId="milk_bottle" size={48} />
            <ProductArtwork productId="honey_jar" size={48} />
            <ProductArtwork productId="olive_oil" size={48} />
            <ProductArtwork productId="strawberry_jam" size={48} />
            <ProductArtwork productId="mint_tea" size={48} />
          </View>
          <View style={styles.miniShelfPlank} />
        </View>
      </View>

      {/* Quick Player Summary Bar */}
      <View style={styles.summaryRow}>
        <View style={styles.summaryCard}>
          <Ionicons name="star" size={20} color={ShelfColors.amberGold} />
          <Text style={styles.summaryValue}>{totalStars}</Text>
          <Text style={styles.summaryLabel}>مجموع النجوم</Text>
        </View>
        <View style={styles.summaryCard}>
          <Ionicons name="trophy" size={20} color={ShelfColors.greenPrimary} />
          <Text style={styles.summaryValue}>{playerStats.highestScoreEver}</Text>
          <Text style={styles.summaryLabel}>أعلى نتيجة</Text>
        </View>
        <View style={styles.summaryCard}>
          <Ionicons name="layers" size={20} color={ShelfColors.orangePrimary} />
          <Text style={styles.summaryValue}>
            {playerStats.totalTripletsMatched}
          </Text>
          <Text style={styles.summaryLabel}>ثلاثيات مرتبة</Text>
        </View>
      </View>

      {/* Active Saved Session Card (Room Local Session Recovery) */}
      {savedSession && (
        <View style={styles.savedSessionCard}>
          <View style={styles.savedSessionHeader}>
            <View style={styles.savedSessionPulseDot} />
            <Text style={styles.savedSessionTitle}>
              جلسة لعب محفوظة محلياً
            </Text>
          </View>
          <Text style={styles.savedSessionDetails}>
            المستوى: {DIFFICULTY_CONFIGS[savedSession.difficulty].titleAr} •
            المرحلة {savedSession.levelNumber} • الثلاثيات:{' '}
            {savedSession.matchedTripletsCount} / {savedSession.totalTriplets} •
            النقاط: {savedSession.score}
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={onResumeSavedGame}
            style={({ pressed }) => [
              styles.resumeButton,
              pressed && styles.buttonPressed,
            ]}
          >
            <Ionicons name="play" size={18} color={ShelfColors.inkOnDark} />
            <Text style={styles.resumeButtonText}>
              متابعة الجلسة المحفوظة
            </Text>
          </Pressable>
        </View>
      )}

      {/* Primary CTA: Start / Choose Difficulty */}
      <Pressable
        accessibilityRole="button"
        onPress={onOpenDifficultySelect}
        style={({ pressed }) => [
          styles.primaryPlayButton,
          pressed && styles.buttonPressed,
        ]}
      >
        <View style={styles.primaryPlayContent}>
          <View style={styles.primaryPlayTextCol}>
            <Text style={styles.primaryPlayTitle}>ابدأ اللعب واختر الصعوبة</Text>
            <Text style={styles.primaryPlaySub}>
              سهل • متوسط • صعب (مراحل مضمونة الحل ١٠٠٪)
            </Text>
          </View>
          <View style={styles.primaryPlayIconCircle}>
            <Ionicons name="grid" size={24} color={ShelfColors.greenDark} />
          </View>
        </View>
      </Pressable>

      {/* Secondary Navigation Grid */}
      <View style={styles.secondaryButtonsGrid}>
        <Pressable
          accessibilityRole="button"
          onPress={onOpenStats}
          style={({ pressed }) => [
            styles.secondaryNavCard,
            pressed && styles.buttonPressed,
          ]}
        >
          <View
            style={[
              styles.secondaryIconWrap,
              { backgroundColor: ShelfColors.greenLight },
            ]}
          >
            <Ionicons
              name="bar-chart"
              size={22}
              color={ShelfColors.greenPrimary}
            />
          </View>
          <Text style={styles.secondaryNavTitle}>الإحصائيات</Text>
          <Text style={styles.secondaryNavSubtitle}>
            سجل الفوز والنجوم ومعرض المنتجات
          </Text>
        </Pressable>

        <Pressable
          accessibilityRole="button"
          onPress={onOpenSettings}
          style={({ pressed }) => [
            styles.secondaryNavCard,
            pressed && styles.buttonPressed,
          ]}
        >
          <View
            style={[
              styles.secondaryIconWrap,
              { backgroundColor: ShelfColors.orangeLight },
            ]}
          >
            <Ionicons
              name="settings"
              size={22}
              color={ShelfColors.orangePrimary}
            />
          </View>
          <Text style={styles.secondaryNavTitle}>الإعدادات والنظام</Text>
          <Text style={styles.secondaryNavSubtitle}>
            التفضيلات وفحص المعمارية والكود
          </Text>
        </Pressable>
      </View>

      {/* How to Play & Product Catalog Banner */}
      <Pressable
        accessibilityRole="button"
        onPress={() => setShowGuideModal(true)}
        style={({ pressed }) => [
          styles.guideBannerButton,
          pressed && styles.buttonPressed,
        ]}
      >
        <Ionicons
          name="help-circle"
          size={22}
          color={ShelfColors.woodDarkFrame}
        />
        <Text style={styles.guideBannerText}>
          طريقة اللعب وقواعد منطقة التجميع ذات الـ ٧ خانات
        </Text>
        <Ionicons
          name="chevron-back"
          size={18}
          color={ShelfColors.inkSecondary}
        />
      </Pressable>

      {/* How to Play Modal */}
      <Modal
        visible={showGuideModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowGuideModal(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>كيف تلعب «رتّب الرفوف»؟</Text>

            <View style={styles.ruleItem}>
              <View style={styles.ruleBadge}>
                <Text style={styles.ruleBadgeText}>١</Text>
              </View>
              <Text style={styles.ruleText}>
                اختر أي منتج متاح في الصف الأمامي من الرفوف الخشبية لنقله إلى
                منطقة التجميع السفلية (٧ خانات).
              </Text>
            </View>

            <View style={styles.ruleItem}>
              <View style={styles.ruleBadge}>
                <Text style={styles.ruleBadgeText}>٢</Text>
              </View>
              <Text style={styles.ruleText}>
                عند اختيار منتج أمامي، يتقدم المنتج الموجود خلفه تلقائياً ليصبح
                متاحاً للفرز.
              </Text>
            </View>

            <View style={styles.ruleItem}>
              <View style={styles.ruleBadge}>
                <Text style={styles.ruleBadgeText}>٣</Text>
              </View>
              <Text style={styles.ruleText}>
                بمجرد اجتماع ٣ منتجات متطابقة في منطقة التجميع، تختفي تلقائياً
                وتحصل على نقاط ومضاعف السلسلة!
              </Text>
            </View>

            <View style={styles.ruleItem}>
              <View
                style={[
                  styles.ruleBadge,
                  { backgroundColor: ShelfColors.dangerRed },
                ]}
              >
                <Text style={styles.ruleBadgeText}>٤</Text>
              </View>
              <Text style={styles.ruleText}>
                احذر من امتلاء جميع الخانات الـ ٧ دون تكوين ثلاثية متطابقة!
                يمكنك استخدام التراجع أو التلميح في الأوقات الحرجة.
              </Text>
            </View>

            <Text style={styles.catalogSectionLabel}>
              أصناف متجر المونة ({PRODUCT_CATALOG.length} منتجاً برسومات أصلية):
            </Text>
            <View style={styles.catalogMiniGrid}>
              {PRODUCT_CATALOG.slice(0, 6).map((item) => (
                <View key={item.id} style={styles.catalogMiniCell}>
                  <ProductArtwork productId={item.id} size={38} />
                  <Text style={styles.catalogMiniName}>{item.nameAr}</Text>
                </View>
              ))}
            </View>

            <Pressable
              accessibilityRole="button"
              onPress={() => setShowGuideModal(false)}
              style={styles.modalCloseBtn}
            >
              <Text style={styles.modalCloseBtnText}>فهمت، لنبدأ الترتيب!</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  contentContainer: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 32,
  },
  heroBanner: {
    backgroundColor: ShelfColors.woodDarkFrame,
    borderRadius: 20,
    padding: 18,
    borderWidth: 3,
    borderColor: ShelfColors.woodLightTrim,
    marginBottom: 14,
    shadowColor: '#2A180D',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 6,
  },
  heroSignHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  offlineBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: 'rgba(46, 111, 64, 0.85)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 5,
  },
  offlineBadgeText: {
    color: ShelfColors.creamSurface,
    fontSize: 11,
    fontWeight: '700',
  },
  noTimerBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: 'rgba(217, 107, 39, 0.85)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 5,
  },
  noTimerBadgeText: {
    color: ShelfColors.creamSurface,
    fontSize: 11,
    fontWeight: '700',
  },
  heroTitleAr: {
    fontSize: 32,
    fontWeight: '900',
    color: ShelfColors.creamSurface,
    textAlign: 'center',
  },
  heroSubtitleAr: {
    fontSize: 13,
    fontWeight: '600',
    color: ShelfColors.woodSlotTrayBg,
    textAlign: 'center',
    marginTop: 2,
    marginBottom: 14,
  },
  miniShelfRack: {
    backgroundColor: ShelfColors.woodInteriorShadow,
    borderRadius: 12,
    paddingTop: 10,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: ShelfColors.woodMediumPlank,
  },
  miniShelfRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    paddingHorizontal: 8,
    paddingBottom: 4,
  },
  miniShelfPlank: {
    height: 10,
    backgroundColor: ShelfColors.woodMediumPlank,
    borderTopWidth: 2,
    borderTopColor: ShelfColors.woodLightTrim,
  },
  summaryRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 8,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 8,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '900',
    color: ShelfColors.inkPrimary,
    marginTop: 4,
  },
  summaryLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    marginTop: 2,
  },
  savedSessionCard: {
    backgroundColor: ShelfColors.amberLight,
    borderRadius: 16,
    padding: 14,
    borderWidth: 2,
    borderColor: ShelfColors.orangePrimary,
    marginBottom: 14,
  },
  savedSessionHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 4,
    gap: 8,
  },
  savedSessionPulseDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: ShelfColors.orangePrimary,
  },
  savedSessionTitle: {
    fontSize: 15,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  savedSessionDetails: {
    fontSize: 12,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginBottom: 10,
  },
  resumeButton: {
    backgroundColor: ShelfColors.orangePrimary,
    borderRadius: 12,
    paddingVertical: 11,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  resumeButtonText: {
    color: ShelfColors.inkOnDark,
    fontSize: 15,
    fontWeight: '800',
  },
  primaryPlayButton: {
    backgroundColor: ShelfColors.greenPrimary,
    borderRadius: 18,
    padding: 18,
    marginBottom: 14,
    borderWidth: 2,
    borderColor: ShelfColors.greenDark,
    shadowColor: ShelfColors.greenDark,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 5,
  },
  primaryPlayContent: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  primaryPlayTextCol: {
    flex: 1,
    alignItems: 'flex-end',
    paddingLeft: 12,
  },
  primaryPlayTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: ShelfColors.inkOnDark,
    textAlign: 'right',
  },
  primaryPlaySub: {
    fontSize: 12,
    fontWeight: '600',
    color: ShelfColors.greenLight,
    marginTop: 4,
    textAlign: 'right',
  },
  primaryPlayIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: ShelfColors.creamSurface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondaryButtonsGrid: {
    flexDirection: 'row-reverse',
    gap: 10,
    marginBottom: 14,
  },
  secondaryNavCard: {
    flex: 1,
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 16,
    padding: 14,
    alignItems: 'flex-end',
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  secondaryIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  secondaryNavTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
    textAlign: 'right',
  },
  secondaryNavSubtitle: {
    fontSize: 11,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginTop: 3,
  },
  guideBannerButton: {
    backgroundColor: ShelfColors.creamElevated,
    borderRadius: 14,
    paddingVertical: 13,
    paddingHorizontal: 14,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  guideBannerText: {
    flex: 1,
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
    marginHorizontal: 10,
  },
  buttonPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.985 }],
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(32, 20, 11, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 18,
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 20,
    padding: 20,
    borderWidth: 2.5,
    borderColor: ShelfColors.woodMediumPlank,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'center',
    marginBottom: 14,
  },
  ruleItem: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    marginBottom: 10,
    gap: 10,
  },
  ruleBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: ShelfColors.greenPrimary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  ruleBadgeText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '800',
  },
  ruleText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 20,
    fontWeight: '600',
    color: ShelfColors.inkPrimary,
    textAlign: 'right',
  },
  catalogSectionLabel: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
    marginTop: 8,
    marginBottom: 8,
  },
  catalogMiniGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  catalogMiniCell: {
    width: '31%',
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 10,
    paddingVertical: 6,
    alignItems: 'center',
    marginBottom: 6,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
  },
  catalogMiniName: {
    fontSize: 10,
    fontWeight: '700',
    color: ShelfColors.inkPrimary,
    marginTop: 2,
  },
  modalCloseBtn: {
    backgroundColor: ShelfColors.greenPrimary,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalCloseBtnText: {
    color: ShelfColors.inkOnDark,
    fontSize: 15,
    fontWeight: '800',
  },
});
