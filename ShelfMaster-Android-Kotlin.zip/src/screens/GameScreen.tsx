import React from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { CollectionTrayBar } from '../components/CollectionTrayBar';
import { ProductArtwork } from '../components/ProductArtwork';
import { ShelfCompartmentView } from '../components/ShelfCompartmentView';
import {
  DIFFICULTY_CONFIGS,
  type GameSettings,
  type GameState,
  type ShelfCompartment,
} from '../domain/models';
import type { LevelCompletionSummary } from '../domain/ScoreManager';
import { ShelfColors } from '../theme/colors';

interface GameScreenProps {
  gameState: GameState;
  settings: GameSettings;
  winSummary: LevelCompletionSummary | null;
  onSelectShelfSlot: (compartmentId: string, columnIndex: number) => void;
  onUndo: (emergencyRevive?: boolean) => void;
  onHint: () => void;
  onTogglePause: (paused: boolean) => void;
  onRestartLevel: () => void;
  onNextLevel: () => void;
  onSaveAndExitToMenu: () => void;
  onUpdateSettings: (nextSettings: GameSettings) => void;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  gameState,
  settings,
  winSummary,
  onSelectShelfSlot,
  onUndo,
  onHint,
  onTogglePause,
  onRestartLevel,
  onNextLevel,
  onSaveAndExitToMenu,
  onUpdateSettings,
}) => {
  const diffConfig = DIFFICULTY_CONFIGS[gameState.difficulty];
  const progressRatio =
    gameState.totalTriplets > 0
      ? gameState.matchedTripletsCount / gameState.totalTriplets
      : 0;

  // Group compartments into rows of 2 for balanced wooden rack layout
  const compartmentRows: ShelfCompartment[][] = [];
  for (let i = 0; i < gameState.compartments.length; i += 2) {
    compartmentRows.push(gameState.compartments.slice(i, i + 2));
  }

  const canUndo =
    gameState.undoStack.length > 0 && gameState.undosRemaining > 0;
  const canHint = gameState.hintsRemaining > 0;

  return (
    <View style={styles.container}>
      {/* Top RTL Game HUD Header */}
      <View style={styles.hudHeader}>
        <View style={styles.hudTopRow}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="إيقاف مؤقت"
            onPress={() => onTogglePause(true)}
            style={styles.pauseIconButton}
          >
            <Ionicons
              name="pause"
              size={18}
              color={ShelfColors.woodDarkFrame}
            />
            <Text style={styles.pauseBtnLabel}>إيقاف</Text>
          </Pressable>

          <View style={styles.levelBadgeRow}>
            <View
              style={[
                styles.diffPill,
                { backgroundColor: diffConfig.badgeColor },
              ]}
            >
              <Text style={styles.diffPillText}>{diffConfig.titleAr}</Text>
            </View>
            <Text style={styles.levelTitleText}>
              المرحلة {gameState.levelNumber}
            </Text>
          </View>

          <View style={styles.scoreBox}>
            <Text style={styles.scoreLabel}>النقاط</Text>
            <Text style={styles.scoreValue}>{gameState.score}</Text>
          </View>
        </View>

        {/* Progress & Combo Bar */}
        <View style={styles.hudProgressRow}>
          <View style={styles.progressTrackWrap}>
            <View style={styles.progressLabelsRow}>
              <Text style={styles.progressTitle}>
                الثلاثيات المرتبة: {gameState.matchedTripletsCount} /{' '}
                {gameState.totalTriplets}
              </Text>
              <Text style={styles.noTimerCalmText}>بدون مؤقت • لعب هادئ</Text>
            </View>
            <View style={styles.progressBarBg}>
              <View
                style={[
                  styles.progressBarFill,
                  { width: `${Math.min(100, Math.round(progressRatio * 100))}%` },
                ]}
              />
            </View>
          </View>

          {gameState.comboCount > 1 && (
            <View style={styles.comboPill}>
              <Text style={styles.comboPillText}>
                سلسلة ×{gameState.comboCount}
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* Active Hint Banner */}
      {gameState.activeHint && (
        <View style={styles.hintBanner}>
          <View style={styles.hintBannerRow}>
            <ProductArtwork
              productId={gameState.activeHint.productId}
              size={34}
            />
            <Text style={styles.hintBannerText}>
              {gameState.activeHint.reasonAr}
            </Text>
          </View>
        </View>
      )}

      {/* Main Wooden Shelves Rack */}
      <ScrollView
        style={styles.shelvesScrollArea}
        contentContainerStyle={styles.shelvesScrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.woodenCabinetOuter}>
          {compartmentRows.map((row, rowIndex) => (
            <View key={`row_${rowIndex}`} style={styles.compartmentRowRtl}>
              {row.map((comp) => (
                <ShelfCompartmentView
                  key={comp.compartmentId}
                  compartment={comp}
                  showBackLayerPreview={settings.showBackLayerPreview}
                  highContrastLabels={settings.highContrastLabels}
                  activeHint={gameState.activeHint}
                  onSelectSlot={onSelectShelfSlot}
                />
              ))}
            </View>
          ))}
        </View>
      </ScrollView>

      {/* 7-Slot Collection Area */}
      <CollectionTrayBar
        traySlots={gameState.traySlots}
        lastMatchedProductId={gameState.lastMatchedProductId}
      />

      {/* Bottom RTL Assist Controls Bar */}
      <View style={styles.bottomControlsBar}>
        {/* Undo Button */}
        <Pressable
          accessibilityRole="button"
          disabled={!canUndo}
          onPress={() => onUndo(false)}
          style={[
            styles.assistButton,
            !canUndo && styles.assistButtonDisabled,
          ]}
        >
          <View style={styles.assistIconRow}>
            <Ionicons
              name="arrow-undo"
              size={18}
              color={
                canUndo ? ShelfColors.woodDarkFrame : ShelfColors.inkMuted
              }
            />
            <View style={styles.countBadge}>
              <Text style={styles.countBadgeText}>
                {gameState.undosRemaining}
              </Text>
            </View>
          </View>
          <Text
            style={[
              styles.assistLabel,
              !canUndo && styles.assistLabelDisabled,
            ]}
          >
            تراجع
          </Text>
        </Pressable>

        {/* Hint Button */}
        <Pressable
          accessibilityRole="button"
          disabled={!canHint}
          onPress={onHint}
          style={[
            styles.assistButton,
            styles.assistButtonHint,
            !canHint && styles.assistButtonDisabled,
          ]}
        >
          <View style={styles.assistIconRow}>
            <Ionicons
              name="bulb"
              size={18}
              color={
                canHint ? ShelfColors.orangeDark : ShelfColors.inkMuted
              }
            />
            <View
              style={[
                styles.countBadge,
                { backgroundColor: ShelfColors.orangePrimary },
              ]}
            >
              <Text style={styles.countBadgeText}>
                {gameState.hintsRemaining}
              </Text>
            </View>
          </View>
          <Text
            style={[
              styles.assistLabel,
              { color: ShelfColors.orangeDark },
              !canHint && styles.assistLabelDisabled,
            ]}
          >
            تلميح
          </Text>
        </Pressable>

        {/* Restart Level Button */}
        <Pressable
          accessibilityRole="button"
          onPress={onRestartLevel}
          style={styles.assistButton}
        >
          <Ionicons
            name="refresh"
            size={18}
            color={ShelfColors.woodDarkFrame}
          />
          <Text style={styles.assistLabel}>إعادة</Text>
        </Pressable>

        {/* Save & Exit to Menu Button */}
        <Pressable
          accessibilityRole="button"
          onPress={onSaveAndExitToMenu}
          style={styles.assistButton}
        >
          <Ionicons
            name="home"
            size={18}
            color={ShelfColors.greenPrimary}
          />
          <Text style={[styles.assistLabel, { color: ShelfColors.greenDark }]}>
            حفظ وخروج
          </Text>
        </Pressable>
      </View>

      {/* PAUSE MODAL (نافذة الإيقاف المؤقت) */}
      <Modal
        visible={gameState.status === 'PAUSED'}
        transparent={true}
        animationType="fade"
        onRequestClose={() => onTogglePause(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeaderBadge}>
              <Ionicons
                name="pause-circle"
                size={32}
                color={ShelfColors.woodDarkFrame}
              />
              <Text style={styles.modalTitle}>اللعبة متوقفة مؤقتاً</Text>
            </View>
            <Text style={styles.modalSubtitle}>
              المرحلة {gameState.levelNumber} • مستوى {diffConfig.titleAr} •
              تقدمك محفوظ تلقائياً
            </Text>

            {/* Quick In-Game Toggles */}
            <View style={styles.quickSettingsBox}>
              <View style={styles.quickSettingRow}>
                <Text style={styles.quickSettingLabel}>
                  إظهار ظل الطبقة الخلفية للرف
                </Text>
                <Switch
                  value={settings.showBackLayerPreview}
                  onValueChange={(val) =>
                    onUpdateSettings({
                      ...settings,
                      showBackLayerPreview: val,
                    })
                  }
                  trackColor={{
                    false: ShelfColors.creamBorder,
                    true: ShelfColors.greenPrimary,
                  }}
                />
              </View>

              <View style={styles.quickSettingRow}>
                <Text style={styles.quickSettingLabel}>
                  إظهار أسماء المنتجات على الرفوف
                </Text>
                <Switch
                  value={settings.highContrastLabels}
                  onValueChange={(val) =>
                    onUpdateSettings({
                      ...settings,
                      highContrastLabels: val,
                    })
                  }
                  trackColor={{
                    false: ShelfColors.creamBorder,
                    true: ShelfColors.greenPrimary,
                  }}
                />
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              onPress={() => onTogglePause(false)}
              style={[
                styles.modalPrimaryBtn,
                { backgroundColor: ShelfColors.greenPrimary },
              ]}
            >
              <Ionicons name="play" size={18} color="#FFF" />
              <Text style={styles.modalPrimaryBtnText}>متابعة اللعب</Text>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              onPress={onRestartLevel}
              style={styles.modalSecondaryBtn}
            >
              <Ionicons
                name="refresh"
                size={18}
                color={ShelfColors.woodDarkFrame}
              />
              <Text style={styles.modalSecondaryBtnText}>
                إعادة المرحلة من البداية
              </Text>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              onPress={onSaveAndExitToMenu}
              style={styles.modalOutlineBtn}
            >
              <Text style={styles.modalOutlineBtnText}>
                حفظ الجلسة والعودة للقائمة الرئيسية
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {/* WIN MODAL (شاشة الفوز وإتمام ترتيب الرفوف) */}
      <Modal
        visible={gameState.status === 'WON'}
        transparent={true}
        animationType="fade"
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.winCelebrationBadge}>أحسنت الترتيب!</Text>
            <Text style={styles.modalTitle}>
              اكتملت المرحلة {gameState.levelNumber} بنجاح
            </Text>

            {/* Stars Row */}
            <View style={styles.starsRow}>
              {[1, 2, 3].map((starIdx) => {
                const earned = (winSummary?.starsEarned ?? 3) >= starIdx;
                return (
                  <Ionicons
                    key={starIdx}
                    name={earned ? 'star' : 'star-outline'}
                    size={38}
                    color={
                      earned ? ShelfColors.amberGold : ShelfColors.creamBorder
                    }
                  />
                );
              })}
            </View>

            {/* Score Breakdown */}
            <View style={styles.scoreBreakdownCard}>
              <View style={styles.breakdownRow}>
                <Text style={styles.breakdownLabel}>نقاط المطابقات:</Text>
                <Text style={styles.breakdownValue}>
                  {winSummary?.baseScore ?? gameState.score}
                </Text>
              </View>
              <View style={styles.breakdownRow}>
                <Text style={styles.breakdownLabel}>مكافأة كفاءة الحركات:</Text>
                <Text style={styles.breakdownValue}>
                  +{winSummary?.efficiencyBonus ?? 0}
                </Text>
              </View>
              <View style={styles.breakdownRow}>
                <Text style={styles.breakdownLabel}>مكافأة اللعب المتقن:</Text>
                <Text style={styles.breakdownValue}>
                  +{winSummary?.cleanPlayBonus ?? 0}
                </Text>
              </View>
              <View style={[styles.breakdownRow, styles.breakdownTotalRow]}>
                <Text style={styles.breakdownTotalLabel}>المجموع النهائي:</Text>
                <Text style={styles.breakdownTotalValue}>
                  {gameState.score}
                </Text>
              </View>
            </View>

            <Pressable
              accessibilityRole="button"
              onPress={onNextLevel}
              style={[
                styles.modalPrimaryBtn,
                { backgroundColor: ShelfColors.greenPrimary },
              ]}
            >
              <Ionicons name="arrow-back-circle" size={20} color="#FFF" />
              <Text style={styles.modalPrimaryBtnText}>
                الانتقال إلى المرحلة {gameState.levelNumber + 1}
              </Text>
            </Pressable>

            <View style={styles.winFooterButtonsRow}>
              <Pressable
                accessibilityRole="button"
                onPress={onRestartLevel}
                style={[styles.modalSecondaryBtn, { flex: 1 }]}
              >
                <Text style={styles.modalSecondaryBtnText}>إعادة المرحلة</Text>
              </Pressable>

              <Pressable
                accessibilityRole="button"
                onPress={onSaveAndExitToMenu}
                style={[styles.modalSecondaryBtn, { flex: 1 }]}
              >
                <Text style={styles.modalSecondaryBtnText}>القائمة الرئيسية</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* LOSS MODAL (شاشة الخسارة عند امتلاء الخانات السبع) */}
      <Modal
        visible={gameState.status === 'LOST'}
        transparent={true}
        animationType="fade"
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.lossBadgePill}>
              <Ionicons
                name="alert-circle"
                size={22}
                color={ShelfColors.dangerRed}
              />
              <Text style={styles.lossBadgeText}>امتلأت الخانات السبع!</Text>
            </View>

            <Text style={styles.modalTitle}>تعذّرت المطابقة في منطقة التجميع</Text>
            <Text style={styles.modalSubtitle}>
              امتلأت جميع الخانات الـ ٧ بمنتجات مختلفة دون اكتمال ٣ منتجات
              متطابقة. يمكنك التراجع عن الحركة الأخيرة أو إعادة المحاولة!
            </Text>

            {/* Show current 7 items that caused the full tray */}
            <View style={styles.lossTrayPreviewRow}>
              {gameState.traySlots.map((slotItem, idx) => (
                <View key={idx} style={styles.lossTrayMiniCell}>
                  <ProductArtwork productId={slotItem.productId} size={32} />
                </View>
              ))}
            </View>

            {gameState.undoStack.length > 0 && (
              <Pressable
                accessibilityRole="button"
                onPress={() => onUndo(true)}
                style={[
                  styles.modalPrimaryBtn,
                  { backgroundColor: ShelfColors.orangePrimary },
                ]}
              >
                <Ionicons name="arrow-undo" size={18} color="#FFF" />
                <Text style={styles.modalPrimaryBtnText}>
                  تراجع عن الحركة الأخيرة وتابع اللعب
                </Text>
              </Pressable>
            )}

            <Pressable
              accessibilityRole="button"
              onPress={onRestartLevel}
              style={[
                styles.modalPrimaryBtn,
                { backgroundColor: ShelfColors.greenPrimary },
              ]}
            >
              <Ionicons name="refresh" size={18} color="#FFF" />
              <Text style={styles.modalPrimaryBtnText}>
                إعادة المحاولة من البداية
              </Text>
            </Pressable>

            <Pressable
              accessibilityRole="button"
              onPress={onSaveAndExitToMenu}
              style={styles.modalOutlineBtn}
            >
              <Text style={styles.modalOutlineBtnText}>
                العودة إلى القائمة الرئيسية
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  hudHeader: {
    backgroundColor: ShelfColors.creamElevated,
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 8,
    borderBottomWidth: 1.5,
    borderBottomColor: ShelfColors.creamBorder,
  },
  hudTopRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  pauseIconButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 4,
  },
  pauseBtnLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  levelBadgeRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  diffPill: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
  },
  diffPillText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '800',
  },
  levelTitleText: {
    fontSize: 16,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  scoreBox: {
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    alignItems: 'center',
  },
  scoreLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
  },
  scoreValue: {
    fontSize: 15,
    fontWeight: '900',
    color: ShelfColors.greenDark,
  },
  hudProgressRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  progressTrackWrap: {
    flex: 1,
  },
  progressLabelsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 3,
  },
  progressTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
  },
  noTimerCalmText: {
    fontSize: 10,
    fontWeight: '700',
    color: ShelfColors.greenPrimary,
  },
  progressBarBg: {
    height: 7,
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: ShelfColors.greenPrimary,
    borderRadius: 4,
  },
  comboPill: {
    backgroundColor: ShelfColors.orangePrimary,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 10,
  },
  comboPillText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '900',
  },
  hintBanner: {
    backgroundColor: ShelfColors.amberLight,
    marginHorizontal: 12,
    marginTop: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: ShelfColors.orangePrimary,
  },
  hintBannerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  hintBannerText: {
    flex: 1,
    fontSize: 12,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
  },
  shelvesScrollArea: {
    flex: 1,
  },
  shelvesScrollContent: {
    paddingHorizontal: 8,
    paddingTop: 10,
    paddingBottom: 12,
  },
  woodenCabinetOuter: {
    backgroundColor: '#EFE4D0',
    borderRadius: 16,
    paddingTop: 10,
    paddingHorizontal: 4,
    paddingBottom: 2,
    borderWidth: 2,
    borderColor: ShelfColors.woodSlotCellBorder,
  },
  compartmentRowRtl: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  bottomControlsBar: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: ShelfColors.creamSurface,
    borderTopWidth: 1,
    borderTopColor: ShelfColors.creamBorder,
    gap: 8,
  },
  assistButton: {
    flex: 1,
    backgroundColor: ShelfColors.creamElevated,
    borderRadius: 12,
    paddingVertical: 7,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  assistButtonHint: {
    backgroundColor: ShelfColors.orangeLight,
    borderColor: ShelfColors.orangePrimary,
  },
  assistButtonDisabled: {
    opacity: 0.45,
  },
  assistIconRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
  },
  countBadge: {
    backgroundColor: ShelfColors.woodDarkFrame,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
  },
  countBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '800',
  },
  assistLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
    marginTop: 2,
  },
  assistLabelDisabled: {
    color: ShelfColors.inkMuted,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(30, 18, 10, 0.68)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 18,
  },
  modalCard: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 22,
    padding: 20,
    borderWidth: 3,
    borderColor: ShelfColors.woodMediumPlank,
    alignItems: 'center',
  },
  modalHeaderBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  modalTitle: {
    fontSize: 21,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 13,
    lineHeight: 20,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 14,
  },
  quickSettingsBox: {
    width: '100%',
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 14,
    padding: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 10,
  },
  quickSettingRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  quickSettingLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: ShelfColors.inkPrimary,
  },
  modalPrimaryBtn: {
    width: '100%',
    borderRadius: 14,
    paddingVertical: 13,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 10,
  },
  modalPrimaryBtnText: {
    color: '#FFF',
    fontSize: 15,
    fontWeight: '900',
  },
  modalSecondaryBtn: {
    width: '100%',
    backgroundColor: ShelfColors.creamElevated,
    borderRadius: 12,
    paddingVertical: 11,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
    marginBottom: 8,
  },
  modalSecondaryBtnText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  modalOutlineBtn: {
    width: '100%',
    paddingVertical: 10,
    alignItems: 'center',
  },
  modalOutlineBtnText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.inkSecondary,
  },
  winCelebrationBadge: {
    backgroundColor: ShelfColors.greenLight,
    color: ShelfColors.greenDark,
    fontSize: 13,
    fontWeight: '900',
    paddingHorizontal: 14,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 6,
  },
  starsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    gap: 10,
    marginVertical: 12,
  },
  scoreBreakdownCard: {
    width: '100%',
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
    marginBottom: 16,
  },
  breakdownRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  breakdownLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
  },
  breakdownValue: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
  },
  breakdownTotalRow: {
    borderTopWidth: 1,
    borderTopColor: ShelfColors.creamBorder,
    paddingTop: 8,
    marginTop: 4,
    marginBottom: 0,
  },
  breakdownTotalLabel: {
    fontSize: 15,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  breakdownTotalValue: {
    fontSize: 17,
    fontWeight: '900',
    color: ShelfColors.greenPrimary,
  },
  winFooterButtonsRow: {
    flexDirection: 'row-reverse',
    width: '100%',
    gap: 8,
  },
  lossBadgePill: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: ShelfColors.dangerLight,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 14,
    gap: 6,
    marginBottom: 8,
  },
  lossBadgeText: {
    color: ShelfColors.dangerRed,
    fontSize: 13,
    fontWeight: '900',
  },
  lossTrayPreviewRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'center',
    backgroundColor: ShelfColors.woodDarkFrame,
    padding: 8,
    borderRadius: 12,
    gap: 4,
    marginBottom: 16,
  },
  lossTrayMiniCell: {
    backgroundColor: ShelfColors.creamSurface,
    padding: 3,
    borderRadius: 6,
  },
});
