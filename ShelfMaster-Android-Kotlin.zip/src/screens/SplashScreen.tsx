import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ProductArtwork } from '../components/ProductArtwork';
import { ShelfColors } from '../theme/colors';

interface SplashScreenProps {
  onFinishSplash: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinishSplash,
}) => {
  const [progress, setProgress] = useState(0.25);

  useEffect(() => {
    const t1 = setTimeout(() => setProgress(0.65), 300);
    const t2 = setTimeout(() => setProgress(1.0), 650);
    const t3 = setTimeout(() => {
      onFinishSplash();
    }, 1100);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onFinishSplash]);

  return (
    <View style={styles.container}>
      {/* Decorative wooden frame emblem */}
      <View style={styles.emblemCard}>
        <View style={styles.emblemTopBeam}>
          <Text style={styles.emblemTopBeamText}>دكان المونة الكلاسيكي</Text>
        </View>

        <View style={styles.emblemShelfInterior}>
          <ProductArtwork productId="honey_jar" size={62} />
          <ProductArtwork productId="olive_oil" size={62} />
          <ProductArtwork productId="coffee_tin" size={62} />
        </View>

        <View style={styles.emblemBottomPlank} />
      </View>

      {/* Arabic Title & Brand Identity */}
      <Text style={styles.arabicTitle}>رتّب الرفوف</Text>
      <Text style={styles.englishSubtitle}>SHELF MASTER</Text>

      <View style={styles.tagPill}>
        <Text style={styles.tagPillText}>
          ألغاز فرز وترتيب البضائع • بدون إنترنت • بدون مؤقت
        </Text>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressSection}>
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              { width: `${Math.round(progress * 100)}%` },
            ]}
          />
        </View>
        <Text style={styles.loadingText}>
          جاري تجهيز الرفوف واستعادة بياناتك المحلية...
        </Text>
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={onFinishSplash}
        style={({ pressed }) => [
          styles.skipButton,
          pressed && styles.skipButtonPressed,
        ]}
      >
        <Text style={styles.skipButtonText}>الدخول إلى المتجر الآن</Text>
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 28,
  },
  emblemCard: {
    width: 240,
    borderRadius: 18,
    backgroundColor: ShelfColors.woodDarkFrame,
    borderWidth: 3,
    borderColor: ShelfColors.woodLightTrim,
    overflow: 'hidden',
    marginBottom: 24,
    shadowColor: '#2A180D',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 8,
  },
  emblemTopBeam: {
    backgroundColor: ShelfColors.woodMediumPlank,
    paddingVertical: 6,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: ShelfColors.woodLightTrim,
  },
  emblemTopBeamText: {
    color: ShelfColors.creamSurface,
    fontSize: 12,
    fontWeight: '800',
  },
  emblemShelfInterior: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    backgroundColor: ShelfColors.woodInteriorShadow,
    paddingTop: 18,
    paddingBottom: 6,
    paddingHorizontal: 12,
  },
  emblemBottomPlank: {
    height: 16,
    backgroundColor: ShelfColors.woodMediumPlank,
    borderTopWidth: 2,
    borderTopColor: ShelfColors.woodLightTrim,
  },
  arabicTitle: {
    fontSize: 36,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'center',
    marginBottom: 4,
  },
  englishSubtitle: {
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 3,
    color: ShelfColors.greenPrimary,
    textAlign: 'center',
    marginBottom: 14,
  },
  tagPill: {
    backgroundColor: ShelfColors.creamElevated,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    marginBottom: 32,
  },
  tagPillText: {
    fontSize: 12,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    textAlign: 'center',
  },
  progressSection: {
    width: '100%',
    maxWidth: 280,
    alignItems: 'center',
    marginBottom: 24,
  },
  progressTrack: {
    width: '100%',
    height: 10,
    backgroundColor: ShelfColors.creamElevated,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: ShelfColors.woodSlotCellBorder,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: ShelfColors.greenPrimary,
    borderRadius: 6,
  },
  loadingText: {
    fontSize: 12,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    textAlign: 'center',
  },
  skipButton: {
    backgroundColor: ShelfColors.orangePrimary,
    paddingHorizontal: 22,
    paddingVertical: 11,
    borderRadius: 12,
  },
  skipButtonPressed: {
    opacity: 0.88,
    transform: [{ scale: 0.98 }],
  },
  skipButtonText: {
    color: ShelfColors.inkOnDark,
    fontSize: 14,
    fontWeight: '800',
  },
});
