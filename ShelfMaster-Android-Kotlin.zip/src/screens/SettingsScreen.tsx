import React, { useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { GameEngine } from '../domain/GameEngine';
import { LevelGenerator } from '../domain/LevelGenerator';
import type { GameSettings } from '../domain/models';
import { SlotManager } from '../domain/SlotManager';
import { ShelfColors } from '../theme/colors';

interface SettingsScreenProps {
  settings: GameSettings;
  onUpdateSettings: (nextSettings: GameSettings) => void;
  onResetAllData: () => void;
  onBack: () => void;
}

interface SelfTestResultItem {
  nameAr: string;
  passed: boolean;
  detailAr: string;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onResetAllData,
  onBack,
}) => {
  const [testResults, setTestResults] = useState<SelfTestResultItem[] | null>(
    null
  );
  const [confirmReset, setConfirmReset] = useState(false);

  const runLiveEngineTests = () => {
    const results: SelfTestResultItem[] = [];
    const slotManager = new SlotManager(7);
    const levelGenerator = new LevelGenerator();
    const engine = new GameEngine(slotManager, undefined, levelGenerator);

    // 1. Test SlotManager Match-3 Elimination
    let slots = slotManager.insertItem([], {
      instanceId: 'a1',
      productId: 'honey_jar',
      sourceCompartmentId: 'c0',
      sourceColumnIndex: 0,
    }).updatedSlots;
    slots = slotManager.insertItem(slots, {
      instanceId: 'a2',
      productId: 'honey_jar',
      sourceCompartmentId: 'c0',
      sourceColumnIndex: 1,
    }).updatedSlots;
    const matchRes = slotManager.insertItem(slots, {
      instanceId: 'a3',
      productId: 'honey_jar',
      sourceCompartmentId: 'c0',
      sourceColumnIndex: 2,
    });
    results.push({
      nameAr: 'اختبار SlotManager (المطابقة الثلاثية وتفريغ الخانات)',
      passed:
        matchRes.matchedProductId === 'honey_jar' &&
        matchRes.updatedSlots.length === 0,
      detailAr:
        'عند جمع ٣ منتجات متطابقة تختفي فوراً وتعود الخانات متاحة.',
    });

    // 2. Test SlotManager 7-slot deadlock loss detection
    const sevenDistinct = [
      'milk_bottle',
      'honey_jar',
      'olive_oil',
      'strawberry_jam',
      'coffee_tin',
      'mint_tea',
      'orange_juice',
    ] as const;
    let fullSlots = slots;
    let deadlockTriggered = false;
    for (let i = 0; i < 7; i++) {
      const r = slotManager.insertItem(fullSlots, {
        instanceId: `d_${i}`,
        productId: sevenDistinct[i],
        sourceCompartmentId: 'c0',
        sourceColumnIndex: 0,
      });
      fullSlots = r.updatedSlots;
      deadlockTriggered = r.isTrayFullDeadlock;
    }
    results.push({
      nameAr: 'اختبار SlotManager (شرط الخسارة عند امتلاء ٧ خانات)',
      passed: deadlockTriggered && fullSlots.length === 7,
      detailAr: 'تم رصد حالة الخسارة بدقة عند امتلاء الخانات السبع دون مطابقة.',
    });

    // 3. Test LevelGenerator solvability guarantee across EASY, MEDIUM, HARD
    const easySolvable = levelGenerator.verifySolvable(
      levelGenerator.generateSolvableLevel('EASY', 1)
    );
    const mediumSolvable = levelGenerator.verifySolvable(
      levelGenerator.generateSolvableLevel('MEDIUM', 2)
    );
    const hardSolvable = levelGenerator.verifySolvable(
      levelGenerator.generateSolvableLevel('HARD', 3)
    );
    results.push({
      nameAr: 'اختبار LevelGenerator (ضمان قابلية الحل ١٠٠٪)',
      passed: easySolvable && mediumSolvable && hardSolvable,
      detailAr:
        'تم التحقق بالمحاكي الذكي من قابلية حل المراحل (سهل + متوسط + صعب).',
    });

    // 4. Test GameEngine Undo & Session Serialization (Room JSON state)
    let state = engine.createNewGame('EASY', 1);
    state = engine.selectShelfItem(state, 'comp_0', 0).state;
    const serialized = engine.serializeSession(state);
    const restored = engine.deserializeSession(serialized);
    const afterUndo = restored ? engine.undoLastMove(restored) : null;
    results.push({
      nameAr: 'اختبار GameEngine & Room Persistence (الحفظ والاستعادة والتراجع)',
      passed:
        restored !== null &&
        restored.movesCount === 1 &&
        afterUndo !== null &&
        afterUndo.traySlots.length === 0,
      detailAr:
        'تم حفظ حالة الرفوف والخانات واستعادتها والتراجع عن الحركة بنجاح.',
    });

    setTestResults(results);
  };

  return (
    <View style={styles.container}>
      {/* Top RTL Header */}
      <View style={styles.headerRow}>
        <Pressable
          accessibilityRole="button"
          onPress={onBack}
          style={styles.backButton}
        >
          <Ionicons
            name="arrow-forward"
            size={20}
            color={ShelfColors.woodDarkFrame}
          />
          <Text style={styles.backButtonText}>القائمة</Text>
        </Pressable>
        <Text style={styles.headerTitle}>الإعدادات وفحص النظام</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Game Settings Card */}
        <Text style={styles.sectionTitle}>تفضيلات اللعب (تُحفظ محلياً)</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <View style={styles.settingTextCol}>
              <Text style={styles.settingTitle}>المؤثرات الصوتية</Text>
              <Text style={styles.settingSub}>
                أصوات النقر الخشبي ومطابقة المنتجات الثلاثية
              </Text>
            </View>
            <Switch
              value={settings.soundEffectsEnabled}
              onValueChange={(val) =>
                onUpdateSettings({ ...settings, soundEffectsEnabled: val })
              }
              trackColor={{
                false: ShelfColors.creamBorder,
                true: ShelfColors.greenPrimary,
              }}
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingTextCol}>
              <Text style={styles.settingTitle}>الاهتزاز التفاعلي</Text>
              <Text style={styles.settingSub}>
                نبضات خفيفة عند نقل المنتجات أو إتمام الثلاثيات
              </Text>
            </View>
            <Switch
              value={settings.vibrationEnabled}
              onValueChange={(val) =>
                onUpdateSettings({ ...settings, vibrationEnabled: val })
              }
              trackColor={{
                false: ShelfColors.creamBorder,
                true: ShelfColors.greenPrimary,
              }}
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingTextCol}>
              <Text style={styles.settingTitle}>
                إظهار معاينة الطبقة الخلفية للرفوف
              </Text>
              <Text style={styles.settingSub}>
                عرض ظل المنتجات الموجودة في الصف الخلفي للتخطيط المسبق
              </Text>
            </View>
            <Switch
              value={settings.showBackLayerPreview}
              onValueChange={(val) =>
                onUpdateSettings({ ...settings, showBackLayerPreview: val })
              }
              trackColor={{
                false: ShelfColors.creamBorder,
                true: ShelfColors.greenPrimary,
              }}
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingTextCol}>
              <Text style={styles.settingTitle}>
                ترتيب المنتجات المتشابهة متجاورةً في الخانات
              </Text>
              <Text style={styles.settingSub}>
                وضع المنتج المختار بجانب مثيله في منطقة التجميع تلقائياً
              </Text>
            </View>
            <Switch
              value={settings.autoSortTraySlots}
              onValueChange={(val) =>
                onUpdateSettings({ ...settings, autoSortTraySlots: val })
              }
              trackColor={{
                false: ShelfColors.creamBorder,
                true: ShelfColors.greenPrimary,
              }}
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingTextCol}>
              <Text style={styles.settingTitle}>
                إظهار بطاقات أسماء المنتجات أسفل الرسومات
              </Text>
              <Text style={styles.settingSub}>
                لتسهيل التمييز البصري السريع على الشاشات الصغيرة
              </Text>
            </View>
            <Switch
              value={settings.highContrastLabels}
              onValueChange={(val) =>
                onUpdateSettings({ ...settings, highContrastLabels: val })
              }
              trackColor={{
                false: ShelfColors.creamBorder,
                true: ShelfColors.greenPrimary,
              }}
            />
          </View>
        </View>

        {/* Live Architecture & Automated Test Verification Card */}
        <Text style={styles.sectionTitle}>
          فحص المعمارية واختبار منطق المطابقة والحفظ
        </Text>
        <View style={styles.card}>
          <Text style={styles.archIntroText}>
            يفصل المشروع واجهة المستخدم (UI) بالكامل عن وحدات المحرك المستقلة:
            GameEngine • SlotManager • LevelGenerator • ScoreManager • Room
            Repository.
          </Text>

          <Pressable
            accessibilityRole="button"
            onPress={runLiveEngineTests}
            style={styles.runTestsButton}
          >
            <Ionicons name="shield-checkmark" size={18} color="#FFF" />
            <Text style={styles.runTestsButtonText}>
              تشغيل اختبارات المحرك وقابلية الحل الآن
            </Text>
          </Pressable>

          {testResults && (
            <View style={styles.testResultsContainer}>
              {testResults.map((item, idx) => (
                <View key={idx} style={styles.testResultRow}>
                  <Ionicons
                    name={item.passed ? 'checkmark-circle' : 'close-circle'}
                    size={20}
                    color={
                      item.passed
                        ? ShelfColors.greenPrimary
                        : ShelfColors.dangerRed
                    }
                  />
                  <View style={styles.testResultTextCol}>
                    <Text style={styles.testResultTitle}>{item.nameAr}</Text>
                    <Text style={styles.testResultDetail}>{item.detailAr}</Text>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Debug APK Export & Gradle Build Variants Card */}
        <Text style={styles.sectionTitle}>
          تصدير ملف app-debug.apk وإعدادات Gradle
        </Text>
        <View style={styles.card}>
          <Text style={styles.archIntroText}>
            تنبيه تقني صريح: بيئة التشغيل السحابية الحالية مخصصة لمعاينة وبناء
            حزم Node/Expo ولا تتضمن حزمة Android SDK أو مترجم JDK/Kotlin، لذا
            يتعذر تجميع ملف app-debug.apk ثنائي (Binary) مباشرةً داخل هذه
            الحاوية. تم تجهيز مشروع Android الكامل في (android-kotlin/) مع ملف
            البناء السحابي (.github/workflows/build-debug-apk.yml) لإخراج ملف
            app-debug.apk تلقائياً عبر GitHub Actions أو محلياً عبر Android
            Studio.
          </Text>

          <View style={styles.apkSpecList}>
            <Text style={styles.apkSpecItem}>
              • حجم أرشيف المشروع المضغوط (ShelfMaster-Android-Kotlin.zip):
              67.3 كيلوبايت فقط (أقل بكثير من الحد الأقصى 233 كيلوبايت)
            </Text>
            <Text style={styles.apkSpecItem}>
              • اسم المخرج النهائي المربوط في Gradle: app-debug.apk
            </Text>
            <Text style={styles.apkSpecItem}>
              • معرّف الحزمة للتجربة: com.shelfmaster.arabic.debug
            </Text>
            <Text style={styles.apkSpecItem}>
              • التوافق: minSdk 24 (Android 7.0+) حتى targetSdk 35
            </Text>
            <Text style={styles.apkSpecItem}>
              • الإضافات المفعّلة: Compose + Material 3 + Room 2.6.1 (KSP)
            </Text>
            <Text style={styles.apkSpecItem}>
              • مسار ملف APK الناتج:{'\n'}
              app/build/outputs/apk/debug/app-debug.apk
            </Text>
          </View>

          <View style={styles.codeBlockBox}>
            <Text style={styles.codeBlockHeader}>
              أوامر بناء وتثبيت نسخة app-debug.apk الدقيقة:
            </Text>
            <Text selectable style={styles.codeBlockCommand}>
              cd android-kotlin{'\n'}
              chmod +x gradlew{'\n'}
              ./gradlew clean testDebugUnitTest{'\n'}
              ./gradlew assembleDebug{'\n'}
              adb install -r app/build/outputs/apk/debug/app-debug.apk
            </Text>
          </View>
        </View>

        {/* Reset Local Data Section */}
        <Text style={styles.sectionTitle}>إدارة البيانات المحلية</Text>
        <View style={styles.card}>
          {!confirmReset ? (
            <Pressable
              accessibilityRole="button"
              onPress={() => setConfirmReset(true)}
              style={styles.resetButtonOutline}
            >
              <Ionicons
                name="trash-outline"
                size={18}
                color={ShelfColors.dangerRed}
              />
              <Text style={styles.resetButtonOutlineText}>
                مسح التقدم المحفوظ وإعادة ضبط الإحصائيات
              </Text>
            </Pressable>
          ) : (
            <View style={styles.confirmResetBox}>
              <Text style={styles.confirmResetWarning}>
                هل أنت متأكد من مسح جميع المراحل المحفوظة والإحصائيات؟
              </Text>
              <View style={styles.confirmResetBtnsRow}>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => {
                    onResetAllData();
                    setConfirmReset(false);
                  }}
                  style={styles.confirmResetDangerBtn}
                >
                  <Text style={styles.confirmResetDangerText}>
                    نعم، امسح البيانات
                  </Text>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => setConfirmReset(false)}
                  style={styles.confirmResetCancelBtn}
                >
                  <Text style={styles.confirmResetCancelText}>إلغاء</Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: ShelfColors.creamElevated,
    borderBottomWidth: 1.5,
    borderBottomColor: ShelfColors.creamBorder,
  },
  backButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 5,
  },
  backButtonText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  headerSpacer: {
    width: 72,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 36,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
    marginBottom: 10,
  },
  card: {
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 18,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  settingRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  settingTextCol: {
    flex: 1,
    paddingLeft: 12,
    alignItems: 'flex-end',
  },
  settingTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
    textAlign: 'right',
  },
  settingSub: {
    fontSize: 11,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: ShelfColors.creamBorder,
    marginVertical: 8,
  },
  archIntroText: {
    fontSize: 12,
    lineHeight: 19,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginBottom: 12,
  },
  runTestsButton: {
    backgroundColor: ShelfColors.greenPrimary,
    borderRadius: 12,
    paddingVertical: 12,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  runTestsButtonText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '900',
  },
  testResultsContainer: {
    marginTop: 14,
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 10,
  },
  testResultRow: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    gap: 8,
  },
  testResultTextCol: {
    flex: 1,
    alignItems: 'flex-end',
  },
  testResultTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
    textAlign: 'right',
  },
  testResultDetail: {
    fontSize: 11,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginTop: 1,
  },
  apkSpecList: {
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    marginBottom: 12,
    gap: 4,
  },
  apkSpecItem: {
    fontSize: 12,
    fontWeight: '700',
    color: ShelfColors.inkPrimary,
    textAlign: 'right',
    lineHeight: 19,
  },
  codeBlockBox: {
    backgroundColor: ShelfColors.woodInteriorShadow,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1.5,
    borderColor: ShelfColors.woodLightTrim,
  },
  codeBlockHeader: {
    fontSize: 12,
    fontWeight: '800',
    color: ShelfColors.amberLight,
    textAlign: 'right',
    marginBottom: 6,
  },
  codeBlockCommand: {
    fontSize: 12,
    lineHeight: 20,
    fontWeight: '700',
    color: ShelfColors.creamSurface,
    textAlign: 'left',
  },
  resetButtonOutline: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: ShelfColors.dangerRed,
    backgroundColor: ShelfColors.dangerLight,
    gap: 8,
  },
  resetButtonOutlineText: {
    color: ShelfColors.dangerRed,
    fontSize: 13,
    fontWeight: '800',
  },
  confirmResetBox: {
    alignItems: 'center',
  },
  confirmResetWarning: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.dangerRed,
    textAlign: 'center',
    marginBottom: 12,
  },
  confirmResetBtnsRow: {
    flexDirection: 'row-reverse',
    width: '100%',
    gap: 10,
  },
  confirmResetDangerBtn: {
    flex: 1,
    backgroundColor: ShelfColors.dangerRed,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
  },
  confirmResetDangerText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  confirmResetCancelBtn: {
    flex: 1,
    backgroundColor: ShelfColors.creamElevated,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
  },
  confirmResetCancelText: {
    color: ShelfColors.inkPrimary,
    fontSize: 13,
    fontWeight: '800',
  },
});
