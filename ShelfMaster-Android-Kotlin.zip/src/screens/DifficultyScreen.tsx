import React, { useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { ProductArtwork } from '../components/ProductArtwork';
import {
  DIFFICULTY_CONFIGS,
  type Difficulty,
  type PlayerStats,
} from '../domain/models';
import { ShelfColors } from '../theme/colors';

interface DifficultyScreenProps {
  playerStats: PlayerStats;
  onStartLevel: (difficulty: Difficulty, levelNumber: number) => void;
  onBack: () => void;
}

const DIFFICULTIES_ORDER: Difficulty[] = ['EASY', 'MEDIUM', 'HARD'];

export const DifficultyScreen: React.FC<DifficultyScreenProps> = ({
  playerStats,
  onStartLevel,
  onBack,
}) => {
  const [selectedDifficulty, setSelectedDifficulty] =
    useState<Difficulty>('EASY');

  const activeProgress =
    playerStats.progressByDifficulty[selectedDifficulty];

  // Show levels 1..8 for quick stage selection, with unlocked indicator
  const stageNumbers = [1, 2, 3, 4, 5, 6];

  return (
    <View style={styles.container}>
      {/* Top RTL Navigation Header */}
      <View style={styles.headerRow}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="رجوع للقائمة الرئيسية"
          onPress={onBack}
          style={styles.backButton}
        >
          <Ionicons
            name="arrow-forward"
            size={20}
            color={ShelfColors.woodDarkFrame}
          />
          <Text style={styles.backButtonText}>القائمة</Text>
        </Pressable>

        <Text style={styles.headerTitle}>اختر مستوى الصعوبة</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionIntro}>
          جميع المراحل تُولَّد عبر خوارزمية تضمن قابلية الحل ١٠٠٪ دون عشوائية
          مسدودة.
        </Text>

        {/* 3 Difficulty Cards */}
        {DIFFICULTIES_ORDER.map((diffKey) => {
          const config = DIFFICULTY_CONFIGS[diffKey];
          const progress = playerStats.progressByDifficulty[diffKey];
          const isSelected = selectedDifficulty === diffKey;

          const sampleProductId =
            diffKey === 'EASY'
              ? 'milk_bottle'
              : diffKey === 'MEDIUM'
              ? 'honey_jar'
              : 'coffee_tin';

          return (
            <Pressable
              key={diffKey}
              accessibilityRole="button"
              onPress={() => setSelectedDifficulty(diffKey)}
              style={[
                styles.diffCard,
                isSelected && {
                  borderColor: config.badgeColor,
                  borderWidth: 2.5,
                  backgroundColor: ShelfColors.creamSurface,
                },
              ]}
            >
              <View style={styles.diffCardHeader}>
                <View style={styles.diffTitleGroup}>
                  <View
                    style={[
                      styles.diffBadge,
                      { backgroundColor: config.badgeColor },
                    ]}
                  >
                    <Text style={styles.diffBadgeText}>{config.titleAr}</Text>
                  </View>
                  <Text style={styles.diffSubtitleText}>
                    {config.subtitleAr}
                  </Text>
                </View>

                <ProductArtwork productId={sampleProductId} size={46} />
              </View>

              <Text style={styles.diffDescriptionText}>
                {config.descriptionAr}
              </Text>

              {/* Spec Chips */}
              <View style={styles.specChipsRow}>
                <View style={styles.specChip}>
                  <Text style={styles.specChipText}>
                    {config.productTypesCount} أصناف
                  </Text>
                </View>
                <View style={styles.specChip}>
                  <Text style={styles.specChipText}>
                    {config.totalTriplets * 3} منتجاً ({config.totalTriplets}{' '}
                    ثلاثيات)
                  </Text>
                </View>
                <View style={styles.specChip}>
                  <Text style={styles.specChipText}>
                    عمق {config.maxDepthLayers} طبقات
                  </Text>
                </View>
              </View>

              {/* Player Progress Footer inside Card */}
              <View style={styles.cardProgressFooter}>
                <Text style={styles.cardProgressItem}>
                  المرحلة الحالية: {progress.currentLevel}
                </Text>
                <Text style={styles.cardProgressItem}>
                  أعلى نتيجة: {progress.bestScore}
                </Text>
                <Text style={styles.cardProgressItem}>
                  النجوم: {progress.totalStars}
                </Text>
              </View>

              {/* Direct Start Button on each card */}
              <Pressable
                accessibilityRole="button"
                onPress={() => onStartLevel(diffKey, progress.currentLevel)}
                style={[
                  styles.startDiffButton,
                  { backgroundColor: config.badgeColor },
                ]}
              >
                <Ionicons
                  name="play"
                  size={17}
                  color={ShelfColors.inkOnDark}
                />
                <Text style={styles.startDiffButtonText}>
                  العب مستوى «{config.titleAr}» • المرحلة{' '}
                  {progress.currentLevel}
                </Text>
              </Pressable>
            </Pressable>
          );
        })}

        {/* Level Stage Picker for the currently highlighted difficulty */}
        <View style={styles.stagePickerCard}>
          <Text style={styles.stagePickerTitle}>
            اختيار مرحلة محددة في مستوى «
            {DIFFICULTY_CONFIGS[selectedDifficulty].titleAr}»:
          </Text>
          <View style={styles.stageButtonsRow}>
            {stageNumbers.map((stageNum) => {
              const isUnlocked =
                stageNum <= Math.max(1, activeProgress.currentLevel);
              return (
                <Pressable
                  key={stageNum}
                  disabled={!isUnlocked}
                  onPress={() => onStartLevel(selectedDifficulty, stageNum)}
                  style={[
                    styles.stageButton,
                    isUnlocked
                      ? styles.stageButtonUnlocked
                      : styles.stageButtonLocked,
                  ]}
                >
                  <Text
                    style={[
                      styles.stageButtonNumber,
                      !isUnlocked && styles.stageButtonNumberLocked,
                    ]}
                  >
                    المرحلة {stageNum}
                  </Text>
                  <Ionicons
                    name={isUnlocked ? 'play-circle' : 'lock-closed'}
                    size={16}
                    color={
                      isUnlocked
                        ? ShelfColors.greenPrimary
                        : ShelfColors.inkMuted
                    }
                  />
                </Pressable>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: ShelfColors.creamElevated,
    borderBottomWidth: 1.5,
    borderBottomColor: ShelfColors.creamBorder,
  },
  backButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 5,
  },
  backButtonText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  headerSpacer: {
    width: 72,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 36,
  },
  sectionIntro: {
    fontSize: 13,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginBottom: 12,
  },
  diffCard: {
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 18,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
    shadowColor: '#2A180D',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  diffCardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  diffTitleGroup: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
  },
  diffBadge: {
    paddingHorizontal: 14,
    paddingVertical: 5,
    borderRadius: 10,
  },
  diffBadgeText: {
    color: ShelfColors.inkOnDark,
    fontSize: 15,
    fontWeight: '900',
  },
  diffSubtitleText: {
    fontSize: 15,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  diffDescriptionText: {
    fontSize: 13,
    lineHeight: 20,
    color: ShelfColors.inkSecondary,
    textAlign: 'right',
    marginBottom: 10,
  },
  specChipsRow: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 10,
  },
  specChip: {
    backgroundColor: ShelfColors.creamElevated,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
  },
  specChipText: {
    fontSize: 11,
    fontWeight: '700',
    color: ShelfColors.woodDarkFrame,
  },
  cardProgressFooter: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    backgroundColor: ShelfColors.creamBackground,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    marginBottom: 12,
  },
  cardProgressItem: {
    fontSize: 11,
    fontWeight: '800',
    color: ShelfColors.inkSecondary,
  },
  startDiffButton: {
    borderRadius: 12,
    paddingVertical: 12,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  startDiffButtonText: {
    color: ShelfColors.inkOnDark,
    fontSize: 14,
    fontWeight: '900',
  },
  stagePickerCard: {
    backgroundColor: ShelfColors.creamElevated,
    borderRadius: 16,
    padding: 14,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
    marginTop: 4,
  },
  stagePickerTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
    marginBottom: 10,
  },
  stageButtonsRow: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 8,
  },
  stageButton: {
    width: '31%',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 8,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1.5,
  },
  stageButtonUnlocked: {
    backgroundColor: ShelfColors.creamSurface,
    borderColor: ShelfColors.greenPrimary,
  },
  stageButtonLocked: {
    backgroundColor: ShelfColors.creamBackground,
    borderColor: ShelfColors.creamBorder,
    opacity: 0.65,
  },
  stageButtonNumber: {
    fontSize: 12,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
  },
  stageButtonNumberLocked: {
    color: ShelfColors.inkMuted,
  },
});
