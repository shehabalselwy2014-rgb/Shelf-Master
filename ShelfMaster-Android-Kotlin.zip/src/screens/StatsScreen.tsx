import React from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { ProductArtwork } from '../components/ProductArtwork';
import {
  DIFFICULTY_CONFIGS,
  PRODUCT_CATALOG,
  type Difficulty,
  type PlayerStats,
} from '../domain/models';
import { ShelfColors } from '../theme/colors';

interface StatsScreenProps {
  stats: PlayerStats;
  onBack: () => void;
}

const DIFF_KEYS: Difficulty[] = ['EASY', 'MEDIUM', 'HARD'];

export const StatsScreen: React.FC<StatsScreenProps> = ({ stats, onBack }) => {
  const winRate =
    stats.totalGamesPlayed > 0
      ? Math.round((stats.totalGamesWon / stats.totalGamesPlayed) * 100)
      : 0;

  return (
    <View style={styles.container}>
      {/* Top RTL Header */}
      <View style={styles.headerRow}>
        <Pressable
          accessibilityRole="button"
          onPress={onBack}
          style={styles.backButton}
        >
          <Ionicons
            name="arrow-forward"
            size={20}
            color={ShelfColors.woodDarkFrame}
          />
          <Text style={styles.backButtonText}>القائمة</Text>
        </Pressable>
        <Text style={styles.headerTitle}>الإحصائيات وسجل الإنجاز</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Main KPI Grid */}
        <View style={styles.kpiGrid}>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>{stats.totalGamesWon}</Text>
            <Text style={styles.kpiLabel}>مرات الفوز</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>{winRate}%</Text>
            <Text style={styles.kpiLabel}>نسبة الفوز</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>{stats.highestScoreEver}</Text>
            <Text style={styles.kpiLabel}>أعلى نتيجة</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>{stats.totalTripletsMatched}</Text>
            <Text style={styles.kpiLabel}>ثلاثيات مكتملة</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>×{stats.longestCombo}</Text>
            <Text style={styles.kpiLabel}>أطول سلسلة</Text>
          </View>
          <View style={styles.kpiCard}>
            <Text style={styles.kpiValue}>{stats.totalMovesMade}</Text>
            <Text style={styles.kpiLabel}>إجمالي الحركات</Text>
          </View>
        </View>

        {/* Per-Difficulty Progress Breakdown */}
        <Text style={styles.sectionTitle}>التقدم حسب مستوى الصعوبة (Room)</Text>
        {DIFF_KEYS.map((diff) => {
          const cfg = DIFFICULTY_CONFIGS[diff];
          const prog = stats.progressByDifficulty[diff];

          return (
            <View key={diff} style={styles.diffStatCard}>
              <View style={styles.diffStatHeader}>
                <View
                  style={[
                    styles.diffBadge,
                    { backgroundColor: cfg.badgeColor },
                  ]}
                >
                  <Text style={styles.diffBadgeText}>{cfg.titleAr}</Text>
                </View>
                <Text style={styles.diffSubtitle}>{cfg.subtitleAr}</Text>
              </View>

              <View style={styles.diffMetricsRow}>
                <View style={styles.diffMetricCol}>
                  <Text style={styles.diffMetricValue}>
                    {prog.highestLevelCompleted}
                  </Text>
                  <Text style={styles.diffMetricLabel}>مراحل منجزة</Text>
                </View>
                <View style={styles.diffMetricCol}>
                  <Text style={styles.diffMetricValue}>{prog.bestScore}</Text>
                  <Text style={styles.diffMetricLabel}>أفضل نقاط</Text>
                </View>
                <View style={styles.diffMetricCol}>
                  <Text style={styles.diffMetricValue}>{prog.totalStars}</Text>
                  <Text style={styles.diffMetricLabel}>النجوم</Text>
                </View>
                <View style={styles.diffMetricCol}>
                  <Text style={styles.diffMetricValue}>
                    {prog.gamesWon} / {prog.gamesPlayed}
                  </Text>
                  <Text style={styles.diffMetricLabel}>فوز / لعب</Text>
                </View>
              </View>
            </View>
          );
        })}

        {/* Custom Vector Product Catalog Showcase */}
        <Text style={styles.sectionTitle}>
          معرض رسومات المنتجات الأصلية ({PRODUCT_CATALOG.length} صنفاً بدون
          إيموجي)
        </Text>
        <View style={styles.catalogGrid}>
          {PRODUCT_CATALOG.map((product) => (
            <View key={product.id} style={styles.catalogCard}>
              <ProductArtwork productId={product.id} size={48} />
              <Text style={styles.catalogProductName}>{product.nameAr}</Text>
              <Text style={styles.catalogProductCat}>{product.categoryAr}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ShelfColors.creamBackground,
  },
  headerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: ShelfColors.creamElevated,
    borderBottomWidth: 1.5,
    borderBottomColor: ShelfColors.creamBorder,
  },
  backButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: ShelfColors.creamSurface,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
    gap: 5,
  },
  backButtonText: {
    fontSize: 13,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
  },
  headerSpacer: {
    width: 72,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 36,
  },
  kpiGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 18,
  },
  kpiCard: {
    width: '31.5%',
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 8,
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  kpiValue: {
    fontSize: 20,
    fontWeight: '900',
    color: ShelfColors.greenDark,
  },
  kpiLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: ShelfColors.woodDarkFrame,
    textAlign: 'right',
    marginBottom: 10,
    marginTop: 4,
  },
  diffStatCard: {
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1.5,
    borderColor: ShelfColors.creamBorder,
  },
  diffStatHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  diffBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
  },
  diffBadgeText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '900',
  },
  diffSubtitle: {
    fontSize: 14,
    fontWeight: '800',
    color: ShelfColors.woodDarkFrame,
  },
  diffMetricsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    backgroundColor: ShelfColors.creamBackground,
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 10,
  },
  diffMetricCol: {
    alignItems: 'center',
  },
  diffMetricValue: {
    fontSize: 14,
    fontWeight: '900',
    color: ShelfColors.inkPrimary,
  },
  diffMetricLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: ShelfColors.inkSecondary,
    marginTop: 2,
  },
  catalogGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  catalogCard: {
    width: '31.5%',
    backgroundColor: ShelfColors.creamSurface,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 6,
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 1,
    borderColor: ShelfColors.creamBorder,
  },
  catalogProductName: {
    fontSize: 12,
    fontWeight: '800',
    color: ShelfColors.inkPrimary,
    marginTop: 4,
    textAlign: 'center',
  },
  catalogProductCat: {
    fontSize: 10,
    fontWeight: '600',
    color: ShelfColors.inkSecondary,
    marginTop: 1,
    textAlign: 'center',
  },
});
