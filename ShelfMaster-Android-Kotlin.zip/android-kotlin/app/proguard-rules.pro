# Add project specific ProGuard rules here.
-keep class com.shelfmaster.arabic.domain.** { *; }
-keep class com.shelfmaster.arabic.data.** { *; }
