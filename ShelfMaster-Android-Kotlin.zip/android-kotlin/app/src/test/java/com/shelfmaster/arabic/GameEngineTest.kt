package com.shelfmaster.arabic

import com.shelfmaster.arabic.domain.*
import org.junit.Assert.*
import org.junit.Test

class GameEngineTest {

    @Test
    fun slotManager_clearsThreeMatchingProductsAutomatically() {
        val manager = SlotManager(7)
        var slots = emptyList<TraySlotItem>()
        repeat(3) { idx ->
            val res = manager.insertItem(
                slots,
                TraySlotItem("id_$idx", ProductType.HONEY_JAR, "comp_0", idx)
            )
            slots = res.updatedSlots
            if (idx == 2) {
                assertEquals(ProductType.HONEY_JAR, res.matchedProduct)
                assertTrue(slots.isEmpty())
            }
        }
    }

    @Test
    fun slotManager_detectsLossWhenSevenSlotsFullWithoutMatch() {
        val manager = SlotManager(7)
        var slots = emptyList<TraySlotItem>()
        val sevenTypes = ProductType.entries.take(7)
        sevenTypes.forEachIndexed { idx, pType ->
            val res = manager.insertItem(
                slots,
                TraySlotItem("id_$idx", pType, "comp_0", 0)
            )
            slots = res.updatedSlots
            if (idx == 6) {
                assertTrue(res.isTrayFullDeadlock)
                assertEquals(7, slots.size)
            }
        }
    }

    @Test
    fun levelGenerator_guaranteesSolvableLevelsForAllDifficulties() {
        val generator = LevelGenerator()
        for (diff in Difficulty.entries) {
            for (level in 1..5) {
                val compartments = generator.generateSolvableLevel(diff, level)
                assertTrue(
                    "Expected $diff level $level to be solvable",
                    generator.verifySolvable(compartments)
                )
            }
        }
    }
}
