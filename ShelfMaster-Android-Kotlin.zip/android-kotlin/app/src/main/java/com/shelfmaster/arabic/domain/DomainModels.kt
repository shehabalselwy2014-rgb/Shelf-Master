package com.shelfmaster.arabic.domain

enum class Difficulty(
    val titleAr: String,
    val subtitleAr: String,
    val compartmentCount: Int,
    val columnsPerCompartment: Int,
    val maxDepthLayers: Int,
    val productTypesCount: Int,
    val totalTriplets: Int,
    val undoLimit: Int,
    val hintLimit: Int,
    val scoreMultiplier: Double
) {
    EASY("سهل", "رفوف المتجر الصغير", 6, 3, 2, 6, 8, 5, 4, 1.0),
    MEDIUM("متوسط", "دكان البقالة العامر", 8, 3, 2, 9, 12, 4, 3, 1.5),
    HARD("صعب", "المستودع الكبير للخبراء", 8, 3, 3, 12, 16, 3, 3, 2.0)
}

enum class ProductType(
    val id: String,
    val nameAr: String,
    val primaryHex: Long,
    val accentHex: Long
) {
    MILK_BOTTLE("milk_bottle", "قارورة حليب", 0xFFEAF4F8, 0xFF3B7EA1),
    HONEY_JAR("honey_jar", "جرة عسل سدر", 0xFFF6B93B, 0xFFB86B11),
    OLIVE_OIL("olive_oil", "زيت زيتون بكر", 0xFF5B8C3E, 0xFF2E5219),
    STRAWBERRY_JAM("strawberry_jam", "مربى التوت", 0xFFC94141, 0xFF7D1D1D),
    COFFEE_TIN("coffee_tin", "قهوة عربية", 0xFF6D4C3D, 0xFFC89B57),
    MINT_TEA("mint_tea", "شاي بالنعناع", 0xFF2E7D5B, 0xFFD4A84F),
    ORANGE_JUICE("orange_juice", "عصير برتقال", 0xFFEA7A2E, 0xFF3E7A3C),
    WHEAT_FLOUR("wheat_flour", "دقيق القمح", 0xFFE5CFA8, 0xFF8C6239),
    CHEESE_WHEEL("cheese_wheel", "جبن القشقوان", 0xFFF2C94C, 0xFFC48A17),
    TOMATO_PASTE("tomato_paste", "معجون طماطم", 0xFFD64531, 0xFF2E6F40),
    BISCUIT_BOX("biscuit_box", "علبة بسكويت", 0xFFC87A4B, 0xFF5E341A),
    SPICE_JAR("spice_jar", "بهارات زعفران", 0xFFD9822B, 0xFF6B2D14)
}

data class ShelfItem(
    val instanceId: String,
    val productType: ProductType
)

data class ShelfSlotStack(
    val columnIndex: Int,
    val layers: List<ShelfItem>
)

data class ShelfCompartment(
    val compartmentId: String,
    val rowIndex: Int,
    val titleAr: String,
    val slots: List<ShelfSlotStack>
)

data class TraySlotItem(
    val instanceId: String,
    val productType: ProductType,
    val sourceCompartmentId: String,
    val sourceColumnIndex: Int
)

enum class GameStatus {
    PLAYING, PAUSED, WON, LOST
}

data class MoveSnapshot(
    val compartments: List<ShelfCompartment>,
    val traySlots: List<TraySlotItem>,
    val score: Int,
    val comboCount: Int,
    val matchedTripletsCount: Int,
    val movesCount: Int
)

data class HintSuggestion(
    val productType: ProductType,
    val reasonAr: String,
    val targetInstanceIds: Set<String>
)

data class GameState(
    val sessionId: String,
    val levelNumber: Int,
    val difficulty: Difficulty,
    val status: GameStatus,
    val compartments: List<ShelfCompartment>,
    val traySlots: List<TraySlotItem>,
    val score: Int,
    val comboCount: Int,
    val maxComboReached: Int,
    val movesCount: Int,
    val matchedTripletsCount: Int,
    val totalTriplets: Int,
    val undosRemaining: Int,
    val hintsRemaining: Int,
    val undosUsed: Int,
    val hintsUsed: Int,
    val undoStack: List<MoveSnapshot>,
    val activeHint: HintSuggestion? = null,
    val lastMatchedProduct: ProductType? = null
)
