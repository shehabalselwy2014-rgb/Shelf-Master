package com.shelfmaster.arabic.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "player_progress")
data class PlayerProgressEntity(
    @PrimaryKey val difficultyName: String,
    val currentLevel: Int,
    val highestLevelCompleted: Int,
    val bestScore: Int,
    val totalStars: Int,
    val gamesWon: Int,
    val gamesPlayed: Int
)

@Entity(tableName = "player_settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val soundEffectsEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val showBackLayerPreview: Boolean = true,
    val autoSortTraySlots: Boolean = true,
    val highContrastLabels: Boolean = false
)

@Entity(tableName = "saved_game_session")
data class SavedSessionEntity(
    @PrimaryKey val id: Int = 1,
    val sessionId: String,
    val difficultyName: String,
    val levelNumber: Int,
    val serializedStateJson: String,
    val updatedAtEpochMillis: Long
)

@Dao
interface ShelfMasterDao {
    @Query("SELECT * FROM player_progress")
    suspend fun getAllProgress(): List<PlayerProgressEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(progress: PlayerProgressEntity)

    @Query("SELECT * FROM player_settings WHERE id = 1")
    suspend fun getSettings(): SettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: SettingsEntity)

    @Query("SELECT * FROM saved_game_session WHERE id = 1")
    suspend fun getActiveSession(): SavedSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveActiveSession(session: SavedSessionEntity)

    @Query("DELETE FROM saved_game_session")
    suspend fun clearActiveSession()
}

@Database(
    entities = [
        PlayerProgressEntity::class,
        SettingsEntity::class,
        SavedSessionEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ShelfDatabase : RoomDatabase() {
    abstract fun shelfMasterDao(): ShelfMasterDao
}
