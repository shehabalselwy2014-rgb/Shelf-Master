package com.shelfmaster.arabic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shelfmaster.arabic.domain.*

@Composable
fun ShelfMasterAppRoot() {
    val engine = remember { GameEngine() }
    var screen by remember { mutableStateOf("SPLASH") }
    var gameState by remember { mutableStateOf<GameState?>(null) }

    when (screen) {
        "SPLASH" -> {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("رتّب الرفوف", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Color(0xFF5A3821))
                Text("SHELF MASTER", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E6F40))
                Spacer(Modifier.height(24.dp))
                Button(onClick = { screen = "MENU" }) {
                    Text("الدخول إلى المتجر")
                }
            }
        }
        "MENU" -> {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("رتّب الرفوف - القائمة الرئيسية", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Difficulty.entries.forEach { diff ->
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            gameState = engine.createNewGame(diff, 1)
                            screen = "GAME"
                        }
                    ) {
                        Text("ابدأ مستوى «${diff.titleAr}» (${diff.subtitleAr})")
                    }
                }
            }
        }
        "GAME" -> {
            val active = gameState ?: return
            Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("المرحلة ${active.levelNumber} • ${active.difficulty.titleAr}", fontWeight = FontWeight.Bold)
                    Text("النقاط: ${active.score}", fontWeight = FontWeight.Bold, color = Color(0xFF2E6F40))
                }
                Spacer(Modifier.height(8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(active.compartments) { comp ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF3D2414))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(comp.titleAr, color = Color(0xFFFFFDF8), fontSize = 12.sp)
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    comp.slots.forEach { slot ->
                                        val front = slot.layers.firstOrNull()
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clickable(enabled = front != null) {
                                                    gameState = engine.selectShelfItem(
                                                        active,
                                                        comp.compartmentId,
                                                        slot.columnIndex
                                                    ).state
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (front != null) {
                                                ProductArtworkCanvas(front.productType, sizeDp = 44.dp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // 7-Slot Collection Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF5A3821), RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    (0 until 7).forEach { idx ->
                        val item = active.traySlots.getOrNull(idx)
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFFF9F2E6), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFC7AC87), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (item != null) {
                                ProductArtworkCanvas(item.productType, sizeDp = 34.dp)
                            } else {
                                Text("${idx + 1}", fontSize = 11.sp, color = Color(0xFF967F6B))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = { gameState = engine.undoLastMove(active) }
                    ) { Text("تراجع (${active.undosRemaining})") }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = { gameState = engine.requestHint(active) }
                    ) { Text("تلميح (${active.hintsRemaining})") }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = { screen = "MENU" }
                    ) { Text("القائمة") }
                }
            }
        }
    }
}
