package com.shelfmaster.arabic.domain

data class MoveActionOutcome(
    val state: GameState,
    val didMatchTriplet: Boolean,
    val matchedProduct: ProductType?,
    val pointsEarned: Int,
    val completionSummary: LevelCompletionSummary?
)

/**
 * GameEngine coordinates all gameplay logic decoupled from Compose UI:
 * - Selecting front-layer items and promoting back-layer items automatically
 * - Interacting with SlotManager (7 slots) and ScoreManager
 * - Managing Undo stack, Smart Hint calculation, Pause/Resume
 */
class GameEngine(
    private val slotManager: SlotManager = SlotManager(),
    private val scoreManager: ScoreManager = ScoreManager(),
    private val levelGenerator: LevelGenerator = LevelGenerator(slotManager)
) {
    fun createNewGame(difficulty: Difficulty, levelNumber: Int): GameState {
        val compartments = levelGenerator.generateSolvableLevel(difficulty, levelNumber)
        return GameState(
            sessionId = "session_${difficulty.name}_${levelNumber}_${System.currentTimeMillis()}",
            levelNumber = levelNumber,
            difficulty = difficulty,
            status = GameStatus.PLAYING,
            compartments = compartments,
            traySlots = emptyList(),
            score = 0,
            comboCount = 0,
            maxComboReached = 0,
            movesCount = 0,
            matchedTripletsCount = 0,
            totalTriplets = difficulty.totalTriplets,
            undosRemaining = difficulty.undoLimit,
            hintsRemaining = difficulty.hintLimit,
            undosUsed = 0,
            hintsUsed = 0,
            undoStack = emptyList()
        )
    }

    fun selectShelfItem(
        currentState: GameState,
        compartmentId: String,
        columnIndex: Int,
        autoSortTraySlots: Boolean = true
    ): MoveActionOutcome {
        if (currentState.status != GameStatus.PLAYING) {
            return MoveActionOutcome(currentState, false, null, 0, null)
        }

        val compIdx = currentState.compartments.indexOfFirst { it.compartmentId == compartmentId }
        if (compIdx == -1) return MoveActionOutcome(currentState, false, null, 0, null)

        val targetSlot = currentState.compartments[compIdx].slots.firstOrNull { it.columnIndex == columnIndex }
        if (targetSlot == null || targetSlot.layers.isEmpty()) {
            return MoveActionOutcome(currentState, false, null, 0, null)
        }

        val snapshot = MoveSnapshot(
            compartments = currentState.compartments,
            traySlots = currentState.traySlots,
            score = currentState.score,
            comboCount = currentState.comboCount,
            matchedTripletsCount = currentState.matchedTripletsCount,
            movesCount = currentState.movesCount
        )

        val pickedItem = targetSlot.layers.first()
        val updatedCompartments = currentState.compartments.mapIndexed { idx, comp ->
            if (idx != compIdx) comp
            else comp.copy(
                slots = comp.slots.map { slot ->
                    if (slot.columnIndex != columnIndex) slot
                    else slot.copy(layers = slot.layers.drop(1))
                }
            )
        }

        val insertResult = slotManager.insertItem(
            currentSlots = currentState.traySlots,
            newItem = TraySlotItem(
                instanceId = pickedItem.instanceId,
                productType = pickedItem.productType,
                sourceCompartmentId = compartmentId,
                sourceColumnIndex = columnIndex
            ),
            groupSimilarItems = autoSortTraySlots
        )

        var nextScore = currentState.score
        var nextCombo = currentState.comboCount
        var nextMaxCombo = currentState.maxComboReached
        var nextMatched = currentState.matchedTripletsCount
        var pointsEarned = 0

        if (insertResult.matchedProduct != null) {
            val scoreUpdate = scoreManager.calculateMatchScore(
                currentScore = currentState.score,
                currentCombo = currentState.comboCount,
                difficulty = currentState.difficulty
            )
            nextScore = scoreUpdate.newTotalScore
            nextCombo = scoreUpdate.newComboCount
            nextMaxCombo = maxOf(nextMaxCombo, nextCombo)
            nextMatched += 1
            pointsEarned = scoreUpdate.pointsEarned
        }

        val nextMoves = currentState.movesCount + 1
        val remainingShelfItems = countRemainingShelfItems(updatedCompartments)
        var nextStatus = currentState.status
        var summary: LevelCompletionSummary? = null

        if (remainingShelfItems == 0 && insertResult.updatedSlots.isEmpty()) {
            nextStatus = GameStatus.WON
            summary = scoreManager.evaluateLevelWin(
                currentScore = nextScore,
                totalTriplets = currentState.totalTriplets,
                movesCount = nextMoves,
                undosUsed = currentState.undosUsed,
                hintsUsed = currentState.hintsUsed,
                maxComboReached = nextMaxCombo,
                difficulty = currentState.difficulty
            )
            nextScore = summary.finalScore
        } else if (insertResult.isTrayFullDeadlock) {
            nextStatus = GameStatus.LOST
        }

        val nextState = currentState.copy(
            status = nextStatus,
            compartments = updatedCompartments,
            traySlots = insertResult.updatedSlots,
            score = nextScore,
            comboCount = nextCombo,
            maxComboReached = nextMaxCombo,
            movesCount = nextMoves,
            matchedTripletsCount = nextMatched,
            undoStack = (currentState.undoStack.takeLast(14) + snapshot),
            activeHint = null,
            lastMatchedProduct = insertResult.matchedProduct
        )

        return MoveActionOutcome(
            state = nextState,
            didMatchTriplet = insertResult.matchedProduct != null,
            matchedProduct = insertResult.matchedProduct,
            pointsEarned = pointsEarned,
            completionSummary = summary
        )
    }

    fun undoLastMove(currentState: GameState, allowEmergencyRevive: Boolean = false): GameState {
        if (currentState.undoStack.isEmpty()) return currentState
        if (!allowEmergencyRevive && currentState.undosRemaining <= 0) return currentState

        val prev = currentState.undoStack.last()
        return currentState.copy(
            status = GameStatus.PLAYING,
            compartments = prev.compartments,
            traySlots = prev.traySlots,
            score = prev.score,
            comboCount = prev.comboCount,
            matchedTripletsCount = prev.matchedTripletsCount,
            movesCount = prev.movesCount,
            undosRemaining = if (allowEmergencyRevive) currentState.undosRemaining else (currentState.undosRemaining - 1).coerceAtLeast(0),
            undosUsed = currentState.undosUsed + 1,
            undoStack = currentState.undoStack.dropLast(1),
            activeHint = null,
            lastMatchedProduct = null
        )
    }

    fun requestHint(currentState: GameState): GameState {
        if (currentState.status != GameStatus.PLAYING || currentState.hintsRemaining <= 0) {
            return currentState
        }
        val suggestion = findBestHint(currentState) ?: return currentState
        return currentState.copy(
            hintsRemaining = currentState.hintsRemaining - 1,
            hintsUsed = currentState.hintsUsed + 1,
            activeHint = suggestion
        )
    }

    fun findBestHint(currentState: GameState): HintSuggestion? {
        val frontItems = currentState.compartments
            .flatMap { it.slots }
            .mapNotNull { it.layers.firstOrNull() }
            .groupBy { it.productType }

        if (frontItems.isEmpty()) return null
        val trayCounts = slotManager.getCountsByProduct(currentState.traySlots)

        val bestEntry = frontItems.entries.maxByOrNull { (product, items) ->
            val inTray = trayCounts[product] ?: 0
            val onFront = items.size
            when {
                inTray == 2 && onFront >= 1 -> 1000 + onFront
                inTray == 1 && onFront >= 2 -> 700 + onFront
                inTray == 0 && onFront >= 3 -> 500 + onFront
                else -> inTray * 80 + onFront * 25
            }
        } ?: return null

        val needed = (3 - (trayCounts[bestEntry.key] ?: 0)).coerceAtLeast(1)
        return HintSuggestion(
            productType = bestEntry.key,
            reasonAr = "اختر «${bestEntry.key.nameAr}» لإتمام الثلاثية وتفريغ الخانات",
            targetInstanceIds = bestEntry.value.take(needed).map { it.instanceId }.toSet()
        )
    }

    fun setPaused(currentState: GameState, paused: Boolean): GameState {
        if (currentState.status == GameStatus.WON || currentState.status == GameStatus.LOST) {
            return currentState
        }
        return currentState.copy(status = if (paused) GameStatus.PAUSED else GameStatus.PLAYING)
    }

    fun countRemainingShelfItems(compartments: List<ShelfCompartment>): Int {
        return compartments.sumOf { comp -> comp.slots.sumOf { it.layers.size } }
    }
}
