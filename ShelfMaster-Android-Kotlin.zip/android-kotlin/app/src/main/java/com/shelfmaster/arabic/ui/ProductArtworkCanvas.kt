package com.shelfmaster.arabic.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shelfmaster.arabic.domain.ProductType

/**
 * Lightweight original vector illustrations drawn directly on Compose Canvas.
 * Zero emojis used — optimized for smooth 60fps rendering on low/mid-range Android phones.
 */
@Composable
fun ProductArtworkCanvas(
    productType: ProductType,
    sizeDp: Dp = 48.dp,
    dimmed: Boolean = false
) {
    Canvas(modifier = Modifier.size(sizeDp)) {
        val w = size.width
        val h = size.height
        val primary = Color(productType.primaryHex)
        val accent = Color(productType.accentHex)

        // Base product body shape by category
        drawRoundRect(
            color = accent,
            topLeft = Offset(w * 0.2f, h * 0.16f),
            size = Size(w * 0.6f, h * 0.74f),
            cornerRadius = CornerRadius(w * 0.14f, w * 0.14f)
        )
        drawRoundRect(
            color = primary,
            topLeft = Offset(w * 0.24f, h * 0.20f),
            size = Size(w * 0.52f, h * 0.66f),
            cornerRadius = CornerRadius(w * 0.11f, w * 0.11f)
        )
        // Bottle/Jar Lid
        drawRoundRect(
            color = accent,
            topLeft = Offset(w * 0.30f, h * 0.07f),
            size = Size(w * 0.40f, h * 0.10f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
        )
        // Center cream label plaque
        drawRoundRect(
            color = Color(0xFFFFFDF8),
            topLeft = Offset(w * 0.28f, h * 0.42f),
            size = Size(w * 0.44f, h * 0.26f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f)
        )
        // Emblem dot inside label
        drawCircle(
            color = accent,
            radius = w * 0.08f,
            center = Offset(w * 0.5f, h * 0.55f)
        )

        if (dimmed) {
            drawRoundRect(
                color = Color(0x882A180D),
                topLeft = Offset(w * 0.16f, h * 0.06f),
                size = Size(w * 0.68f, h * 0.86f),
                cornerRadius = CornerRadius(w * 0.14f, w * 0.14f)
            )
        }
    }
}
