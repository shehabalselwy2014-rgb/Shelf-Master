package com.shelfmaster.arabic.domain

import kotlin.math.max
import kotlin.math.roundToInt

data class MatchScoreUpdate(
    val pointsEarned: Int,
    val newTotalScore: Int,
    val newComboCount: Int
)

data class LevelCompletionSummary(
    val finalScore: Int,
    val baseScore: Int,
    val efficiencyBonus: Int,
    val cleanPlayBonus: Int,
    val starsEarned: Int
)

class ScoreManager {
    fun calculateMatchScore(
        currentScore: Int,
        currentCombo: Int,
        difficulty: Difficulty
    ): MatchScoreUpdate {
        val nextCombo = currentCombo + 1
        val rawPoints = BASE_TRIPLET_POINTS + (nextCombo - 1) * COMBO_STEP_BONUS
        val pointsEarned = (rawPoints * difficulty.scoreMultiplier).roundToInt()
        return MatchScoreUpdate(
            pointsEarned = pointsEarned,
            newTotalScore = currentScore + pointsEarned,
            newComboCount = nextCombo
        )
    }

    fun evaluateLevelWin(
        currentScore: Int,
        totalTriplets: Int,
        movesCount: Int,
        undosUsed: Int,
        hintsUsed: Int,
        maxComboReached: Int,
        difficulty: Difficulty
    ): LevelCompletionSummary {
        val optimalMoves = totalTriplets * 3
        val extraMoves = max(0, movesCount - optimalMoves)
        val efficiencyBonus = (max(50, 300 - extraMoves * 15) * difficulty.scoreMultiplier).roundToInt()
        val cleanPlayBonus = when {
            undosUsed == 0 && hintsUsed == 0 -> (250 * difficulty.scoreMultiplier).roundToInt()
            undosUsed + hintsUsed <= 2 -> (120 * difficulty.scoreMultiplier).roundToInt()
            else -> 0
        }
        val finalScore = currentScore + efficiencyBonus + cleanPlayBonus
        val stars = when {
            undosUsed + hintsUsed > 4 || extraMoves > 9 -> 1
            undosUsed + hintsUsed > 1 || extraMoves > 3 || maxComboReached < 3 -> 2
            else -> 3
        }
        return LevelCompletionSummary(
            finalScore = finalScore,
            baseScore = currentScore,
            efficiencyBonus = efficiencyBonus,
            cleanPlayBonus = cleanPlayBonus,
            starsEarned = stars
        )
    }

    companion object {
        private const val BASE_TRIPLET_POINTS = 120
        private const val COMBO_STEP_BONUS = 35
    }
}
