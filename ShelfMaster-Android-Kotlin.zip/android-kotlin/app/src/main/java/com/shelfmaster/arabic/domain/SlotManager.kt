package com.shelfmaster.arabic.domain

data class SlotInsertResult(
    val updatedSlots: List<TraySlotItem>,
    val matchedProduct: ProductType?,
    val removedItems: List<TraySlotItem>,
    val isTrayFullDeadlock: Boolean
)

/**
 * Manages the 7-slot collection bar:
 * - Smart insertion adjacent to identical products
 * - Automatic elimination when 3 identical products are collected
 * - Loss condition detection when all 7 slots fill with no triplet match
 */
class SlotManager(val maxSlots: Int = MAX_TRAY_SLOTS) {

    fun insertItem(
        currentSlots: List<TraySlotItem>,
        newItem: TraySlotItem,
        groupSimilarItems: Boolean = true
    ): SlotInsertResult {
        if (currentSlots.size >= maxSlots) {
            return SlotInsertResult(
                updatedSlots = currentSlots,
                matchedProduct = null,
                removedItems = emptyList(),
                isTrayFullDeadlock = true
            )
        }

        val nextSlots = currentSlots.toMutableList()
        if (groupSimilarItems) {
            val lastSameIndex = nextSlots.indexOfLast { it.productType == newItem.productType }
            if (lastSameIndex != -1) {
                nextSlots.add(lastSameIndex + 1, newItem)
            } else {
                nextSlots.add(newItem)
            }
        } else {
            nextSlots.add(newItem)
        }

        val counts = getCountsByProduct(nextSlots)
        val matchedProduct = counts.entries.firstOrNull { it.value >= MATCH_GROUP_SIZE }?.key

        if (matchedProduct != null) {
            val removed = mutableListOf<TraySlotItem>()
            val remaining = mutableListOf<TraySlotItem>()
            for (item in nextSlots) {
                if (item.productType == matchedProduct && removed.size < MATCH_GROUP_SIZE) {
                    removed.add(item)
                } else {
                    remaining.add(item)
                }
            }
            return SlotInsertResult(
                updatedSlots = remaining,
                matchedProduct = matchedProduct,
                removedItems = removed,
                isTrayFullDeadlock = false
            )
        }

        val isDeadlock = nextSlots.size >= maxSlots
        return SlotInsertResult(
            updatedSlots = nextSlots,
            matchedProduct = null,
            removedItems = emptyList(),
            isTrayFullDeadlock = isDeadlock
        )
    }

    fun getCountsByProduct(slots: List<TraySlotItem>): Map<ProductType, Int> {
        return slots.groupingBy { it.productType }.eachCount()
    }

    companion object {
        const val MAX_TRAY_SLOTS = 7
        const val MATCH_GROUP_SIZE = 3
    }
}
