package com.shelfmaster.arabic.domain

import kotlin.random.Random

/**
 * Generates guaranteed-solvable levels using wave-based depth layering
 * and verifies every candidate board with a greedy lookahead solver (`verifySolvable`).
 */
class LevelGenerator(
    private val slotManager: SlotManager = SlotManager()
) {
    private val compartmentTitles = listOf(
        "الرف العلوي الأيمن",
        "الرف العلوي الأيسر",
        "رف المونة الوسطى - أ",
        "رف المونة الوسطى - ب",
        "رف العطارة والأعشاب",
        "رف الألبان والمربيات",
        "الرف السفلي الأيمن",
        "الرف السفلي الأيسر"
    )

    fun generateSolvableLevel(difficulty: Difficulty, levelNumber: Int): List<ShelfCompartment> {
        val baseSeed = levelNumber * 9973L + difficulty.ordinal * 2027L
        for (attempt in 0 until 12) {
            val rng = Random(baseSeed + attempt * 313L)
            val candidate = constructWaveBasedShelves(difficulty, rng)
            if (verifySolvable(candidate)) {
                return candidate
            }
        }
        return constructStrictSolvableShelves(difficulty, Random(baseSeed + 77777L))
    }

    private fun constructWaveBasedShelves(
        difficulty: Difficulty,
        rng: Random
    ): List<ShelfCompartment> {
        val availableProducts = ProductType.entries.shuffled(rng).take(difficulty.productTypesCount)
        val triplets = (0 until difficulty.totalTriplets).map { idx ->
            val p = availableProducts[idx % availableProducts.size]
            listOf(p, p, p)
        }.shuffled(rng)

        val stackMatrix = Array(difficulty.compartmentCount) {
            Array(difficulty.columnsPerCompartment) { mutableListOf<ShelfItem>() }
        }
        val flatStacks = stackMatrix.flatten()
        val waveSize = if (difficulty == Difficulty.EASY) 4 else 3
        var instanceCounter = 1

        for (wave in triplets.chunked(waveSize)) {
            val waveItems = wave.flatten().map { product ->
                ShelfItem("item_${instanceCounter++}_${product.id}", product)
            }.shuffled(rng)

            for (item in waveItems) {
                val eligible = flatStacks.filter { it.size < difficulty.maxDepthLayers }
                val minDepth = eligible.minOfOrNull { it.size } ?: 0
                val candidates = eligible.filter { it.size == minDepth }
                val chosen = candidates[rng.nextInt(candidates.size)]
                chosen.add(item)
            }
        }

        return stackMatrix.mapIndexed { compIdx, cols ->
            ShelfCompartment(
                compartmentId = "comp_$compIdx",
                rowIndex = compIdx / 2,
                titleAr = compartmentTitles.getOrElse(compIdx) { "الرف ${compIdx + 1}" },
                slots = cols.mapIndexed { colIdx, layers ->
                    ShelfSlotStack(columnIndex = colIdx, layers = layers.toList())
                }
            )
        }
    }

    private fun constructStrictSolvableShelves(
        difficulty: Difficulty,
        rng: Random
    ): List<ShelfCompartment> {
        val products = ProductType.entries.take(difficulty.productTypesCount)
        val stackMatrix = Array(difficulty.compartmentCount) {
            Array(difficulty.columnsPerCompartment) { mutableListOf<ShelfItem>() }
        }
        val flatStacks = stackMatrix.flatten()
        val tripletsPerLayer = flatStacks.size / 3
        var remaining = difficulty.totalTriplets
        var counter = 1
        var tIndex = 0

        while (remaining > 0) {
            val batch = minOf(remaining, tripletsPerLayer)
            val layerItems = mutableListOf<ShelfItem>()
            repeat(batch) {
                val p = products[tIndex++ % products.size]
                repeat(3) {
                    layerItems.add(ShelfItem("strict_${counter++}_${p.id}", p))
                }
            }
            val shuffled = layerItems.shuffled(rng)
            val shuffledStacks = flatStacks.shuffled(rng)
            shuffled.forEachIndexed { i, item -> shuffledStacks[i].add(item) }
            remaining -= batch
        }

        return stackMatrix.mapIndexed { compIdx, cols ->
            ShelfCompartment(
                compartmentId = "comp_$compIdx",
                rowIndex = compIdx / 2,
                titleAr = compartmentTitles.getOrElse(compIdx) { "الرف ${compIdx + 1}" },
                slots = cols.mapIndexed { colIdx, layers ->
                    ShelfSlotStack(columnIndex = colIdx, layers = layers.toList())
                }
            )
        }
    }

    fun verifySolvable(compartments: List<ShelfCompartment>): Boolean {
        val allItems = compartments.flatMap { c -> c.slots.flatMap { it.layers } }
        if (allItems.isEmpty() || allItems.size % 3 != 0) return false
        val countsByProduct = allItems.groupingBy { it.productType }.eachCount()
        if (countsByProduct.values.any { it % 3 != 0 }) return false

        val mutableStacks = compartments.associate { comp ->
            comp.compartmentId to comp.slots.map { it.layers.toMutableList() }
        }

        var simTray = emptyList<TraySlotItem>()
        var steps = 0
        val maxSteps = allItems.size + 10

        while (steps++ < maxSteps) {
            data class CandidateMove(
                val compId: String,
                val colIdx: Int,
                val item: ShelfItem,
                val depth: Int
            )

            val frontMoves = mutableListOf<CandidateMove>()
            for ((compId, cols) in mutableStacks) {
                cols.forEachIndexed { colIdx, stack ->
                    if (stack.isNotEmpty()) {
                        frontMoves.add(CandidateMove(compId, colIdx, stack.first(), stack.size))
                    }
                }
            }

            if (frontMoves.isEmpty()) {
                return simTray.isEmpty()
            }

            val trayCounts = slotManager.getCountsByProduct(simTray)
            val frontCounts = frontMoves.groupingBy { it.item.productType }.eachCount()

            val bestMove = frontMoves.maxBy { move ->
                val inTray = trayCounts[move.item.productType] ?: 0
                val onFront = frontCounts[move.item.productType] ?: 0
                val matchScore = when {
                    inTray == 2 -> 1000
                    inTray + onFront >= 3 -> 400 + inTray * 120 + onFront * 25
                    else -> inTray * 60 + onFront * 15
                }
                matchScore + move.depth * 8
            }

            val picked = mutableStacks.getValue(bestMove.compId)[bestMove.colIdx].removeAt(0)
            val result = slotManager.insertItem(
                simTray,
                TraySlotItem(picked.instanceId, picked.productType, bestMove.compId, bestMove.colIdx)
            )
            if (result.isTrayFullDeadlock) return false
            simTray = result.updatedSlots
        }
        return false
    }
}
