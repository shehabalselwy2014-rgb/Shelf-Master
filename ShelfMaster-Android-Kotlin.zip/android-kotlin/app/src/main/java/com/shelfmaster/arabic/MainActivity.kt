package com.shelfmaster.arabic.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.shelfmaster.arabic.ui.ShelfMasterAppRoot

private val ClassicShelfColorScheme = lightColorScheme(
    primary = Color(0xFF2E6F40),       // Classic Forest Green
    onPrimary = Color(0xFFFFFDF8),
    primaryContainer = Color(0xFFDCEFE2),
    secondary = Color(0xFFD96B27),     // Warm Terracotta Orange
    onSecondary = Color(0xFFFFFDF8),
    secondaryContainer = Color(0xFFFDE8D7),
    tertiary = Color(0xFF7D4F2D),      // Warm Oak Wood
    background = Color(0xFFFAF4E8),    // Creamy Parchment
    surface = Color(0xFFFFFDF8),
    onBackground = Color(0xFF2A1C12),
    onSurface = Color(0xFF2A1C12),
    error = Color(0xFFC83E31)
)

@Composable
fun ShelfMasterRtlTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = ClassicShelfColorScheme,
            content = content
        )
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShelfMasterRtlTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ShelfMasterAppRoot()
                }
            }
        }
    }
}
